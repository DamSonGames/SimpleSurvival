document.addEventListener("keydown", keyDownTextField, false);

function keyDownTextField(e) {
var keyCode = e.keyCode;
  if(keyCode==13) {
      console.log("Enter");
      Test();
  }
}

function Test(){
  document.getElementById("StartText").style.display = "none";
  document.getElementById("ItemBlack").style.display = "none";
}