document.addEventListener("keydown", keyDownTextField2, false);

function keyDownTextField2(e) {
var keyCode = e.keyCode;
  if(keyCode==37) {
      TurnLeft();
  }else if(keyCode==38) {
      TurnUp();
  }else if(keyCode==39) {
      TurnRight();
  }else if(keyCode==40) {
      TurnDown();
  }else if(keyCode==32) {
      Space();
  }else if(keyCode==65) {
      Left();
  }else if(keyCode==87) {
      Up();
  }else if(keyCode==68) {
      Right();
  }else if(keyCode==83) {
      Down();
  }else if(keyCode==81) {
      Q();
  }else if(keyCode==49) {
    Crafting1();
  }else if(keyCode==50) {
    Crafting2();
  }else if(keyCode==51) {
    Crafting3();
  }else if(keyCode==52) {
    Crafting4();
  }else if(keyCode==219) {
    CraftLeft();
  }else if(keyCode==221) {
    CraftRight();
  }
}

var value = 3;
var nothing = 0;
var Block;
var blocktype;
var block1 = Math.random();
var block2 = Math.random();
var block3 = Math.random();
var block4 = Math.random();
var block5 = Math.random();
var block6 = Math.random();
var block7 = Math.random();
var block8 = Math.random();
var block9 = Math.random();
var block10 = Math.random();
var block11 = Math.random();
var block12 = Math.random();
var block13 = Math.random();
var block14 = Math.random();
var block15 = Math.random();
var block16 = Math.random();
var block17 = Math.random();
var block18 = Math.random();
var block19 = Math.random();
var block20 = Math.random();
var block21 = Math.random();
var block22 = Math.random();
var block23 = Math.random();
var block24 = Math.random();
var block25 = Math.random();
var block26 = Math.random();
var block27 = Math.random();
var block28 = Math.random();
var block29 = Math.random();
var block30 = Math.random();
var block31 = Math.random();
var block32 = Math.random();
var block33 = Math.random();
var block34 = Math.random();
var block35 = Math.random();
var block36 = Math.random();
var block37 = Math.random();
var block38 = Math.random();
var block39 = Math.random();
var block40 = Math.random();
var block41 = Math.random();
var block42 = Math.random();
var block43 = Math.random();
var block44 = Math.random();
var block45 = Math.random();
var block46 = Math.random();
var block47 = Math.random();
var block48 = Math.random();
var block49 = Math.random();
var block50 = Math.random();
var block51 = Math.random();
var block52 = Math.random();
var block53 = Math.random();
var block54 = Math.random();
var block55 = Math.random();
var block56 = Math.random();
var block57 = Math.random();
var block58 = Math.random();
var block59 = Math.random();
var block60 = Math.random();
var block61 = Math.random();
var block62 = Math.random();
var block63 = Math.random();
var block64 = Math.random();
var block65 = Math.random();
var block66 = Math.random();
var block67 = Math.random();
var block68 = Math.random();
var block69 = Math.random();
var block70 = Math.random();
var blocktype1;
var blocktype2;
var blocktype3;
var blocktype4;
var blocktype5;
var blocktype6;
var blocktype7;
var blocktype8;
var blocktype9;
var blocktype10;
var blocktype11;
var blocktype12;
var blocktype13;
var blocktype14;
var blocktype15;
var blocktype16;
var blocktype17;
var blocktype18;
var blocktype19;
var blocktype20;
var blocktype21;
var blocktype22;
var blocktype23;
var blocktype24;
var blocktype25;
var blocktype26;
var blocktype27;
var blocktype28;
var blocktype29;
var blocktype30;
var blocktype31;
var blocktype32;
var blocktype33;
var blocktype34;
var blocktype35;
var blocktype36;
var blocktype37;
var blocktype38;
var blocktype39;
var blocktype40;
var blocktype41;
var blocktype42;
var blocktype43;
var blocktype44;
var blocktype45;
var blocktype46;
var blocktype47;
var blocktype48;
var blocktype49;
var blocktype50;
var blocktype51;
var blocktype52;
var blocktype53;
var blocktype54;
var blocktype55;
var blocktype56;
var blocktype57;
var blocktype58;
var blocktype59;
var blocktype60;
var blocktype61;
var blocktype62;
var blocktype63;
var blocktype64;
var blocktype65;
var blocktype66;
var blocktype67;
var blocktype68;
var blocktype69;
var blocktype70;
var pos = 35;
var number;
var id;
var pathid;
var direction = 4;
var itemslot1 = 0;
var itemslot2 = 0;
var itemslot3 = 0;
var itemslot4 = 0;
var itemslot5 = 0;
var bamboo = 0;
var rock = 0;
var campfire = 0;
var fire = 0;
var sickle = 0;
var leaf = 0;
var tent = 0;
var shovel = 0;
var wall = 0;
var leafstick = 0;
var roof = 0;
/*
Item To Get:
1 = Bamboo
2 = Rock
3 = Campfire
4 = Fire
5 = Sickle
6 = Leaf
7 = Tent
8 = Shovel
9 = Wall
10 = Leaf Stick
11 = Roof
*/
var itemtoget;
var deleter = 0;
var craftscreen = 1;
var path1 = 0;
var path2 = 0;
var path3 = 0;
var path4 = 0;
var path5 = 0;
var path6 = 0;
var path7 = 0;
var path8 = 0;
var path9 = 0;
var path10 = 0;
var path11 = 0;
var path12 = 0;
var path13 = 0;
var path14 = 0;
var path15 = 0;
var path16 = 0;
var path17 = 0;
var path18 = 0;
var path19 = 0;
var path20 = 0;
var path21 = 0;
var path22 = 0;
var path23 = 0;
var path24 = 0;
var path25 = 0;
var path26 = 0;
var path27 = 0;
var path28 = 0;
var path29 = 0;
var path30 = 0;
var path31 = 0;
var path32 = 0;
var path33 = 0;
var path34 = 0;
var path35 = 0;
var path36 = 0;
var path37 = 0;
var path38 = 0;
var path39 = 0;
var path40 = 0;
var path41 = 0;
var path42 = 0;
var path43 = 0;
var path44 = 0;
var path45 = 0;
var path46 = 0;
var path47 = 0;
var path48 = 0;
var path49 = 0;
var path50 = 0;
var path51 = 0;
var path52 = 0;
var path53 = 0;
var path54 = 0;
var path55 = 0;
var path56 = 0;
var path57 = 0;
var path58 = 0;
var path59 = 0;
var path60 = 0;
var path61 = 0;
var path62 = 0;
var path63 = 0;
var path64 = 0;
var path65 = 0;
var path66 = 0;
var path67 = 0;
var path68 = 0;
var path69 = 0;
var path70 = 0;
var onoroffpath = 0;
var pl = "PL";
var pb = "PB";
var pr = "PR";
var pf = "PF";
var source;
var topath;
var frompath;

if(block1 <= 0.05){
  document.getElementById("BlockImg1").src = "Images/Rock.png";
  blocktype1 = 1;
}else if(block1 > 0.05 && block1 <= 0.1){
  document.getElementById("BlockImg1").src = "Images/Bamboo.png";
  blocktype1 = 2;
}else{
  document.getElementById("BlockImg1").src = "Images/Grass.png";
  blocktype1 = 0;
}

if(block2 <= 0.05){
  document.getElementById("BlockImg2").src = "Images/Rock.png";
  blocktype2 = 1;
}else if(block2 > 0.05 && block2 <= 0.1){
  document.getElementById("BlockImg2").src = "Images/Bamboo.png";
  blocktype2 = 2;
}else{
  document.getElementById("BlockImg2").src = "Images/Grass.png";
  blocktype2 = 0;
}

if(block3 <= 0.05){
  document.getElementById("BlockImg3").src = "Images/Rock.png";
  blocktype3 = 1;
}else if(block3 > 0.05 && block3 <= 0.1){
  document.getElementById("BlockImg3").src = "Images/Bamboo.png";
  blocktype3 = 2;
}else{
  document.getElementById("BlockImg3").src = "Images/Grass.png";
  blocktype3 = 0;
}

if(block4 <= 0.05){
  document.getElementById("BlockImg4").src = "Images/Rock.png";
  blocktype4 = 1;
}else if(block4 > 0.05 && block4 <= 0.1){
  document.getElementById("BlockImg4").src = "Images/Bamboo.png";
  blocktype4 = 2;
}else{
  document.getElementById("BlockImg4").src = "Images/Grass.png";
  blocktype4 = 0;
}

if(block5 <= 0.05){
  document.getElementById("BlockImg5").src = "Images/Rock.png";
  blocktype5 = 1;
}else if(block5 > 0.05 && block5 <= 0.1){
  document.getElementById("BlockImg5").src = "Images/Bamboo.png";
  blocktype5 = 2;
}else{
  document.getElementById("BlockImg5").src = "Images/Grass.png";
  blocktype5 = 0;
}

if(block6 <= 0.05){
  document.getElementById("BlockImg6").src = "Images/Rock.png";
  blocktype6 = 1;
}else if(block6 > 0.05 && block6 <= 0.1){
  document.getElementById("BlockImg6").src = "Images/Bamboo.png";
  blocktype6 = 2;
}else{
  document.getElementById("BlockImg6").src = "Images/Grass.png";
  blocktype6 = 0;
}

if(block7 <= 0.05){
  document.getElementById("BlockImg7").src = "Images/Rock.png";
  blocktype7 = 1;
}else if(block7 > 0.05 && block7 <= 0.1){
  document.getElementById("BlockImg7").src = "Images/Bamboo.png";
  blocktype7 = 2;
}else{
  document.getElementById("BlockImg7").src = "Images/Grass.png";
  blocktype7 = 0;
}

if(block8 <= 0.05){
  document.getElementById("BlockImg8").src = "Images/Rock.png";
  blocktype8 = 1;
}else if(block8 > 0.05 && block8 <= 0.1){
  document.getElementById("BlockImg8").src = "Images/Bamboo.png";
  blocktype8 = 2;
}else{
  document.getElementById("BlockImg8").src = "Images/Grass.png";
  blocktype8 = 0;
}

if(block9 <= 0.05){
  document.getElementById("BlockImg9").src = "Images/Rock.png";
  blocktype9 = 1;
}else if(block9 > 0.05 && block9 <= 0.1){
  document.getElementById("BlockImg9").src = "Images/Bamboo.png";
  blocktype9 = 2;
}else{
  document.getElementById("BlockImg9").src = "Images/Grass.png";
  blocktype9 = 0;
}

if(block10 <= 0.05){
  document.getElementById("BlockImg10").src = "Images/Rock.png";
  blocktype10 = 1;
}else if(block10 > 0.05 && block10 <= 0.1){
  document.getElementById("BlockImg10").src = "Images/Bamboo.png";
  blocktype10 = 2;
}else{
  document.getElementById("BlockImg10").src = "Images/Grass.png";
  blocktype10 = 0;
}

if(block11 <= 0.05){
  document.getElementById("BlockImg11").src = "Images/Rock.png";
  blocktype11 = 1;
}else if(block11 > 0.05 && block11 <= 0.1){
  document.getElementById("BlockImg11").src = "Images/Bamboo.png";
  blocktype11 = 2;
}else{
  document.getElementById("BlockImg11").src = "Images/Grass.png";
  blocktype11 = 0;
}

if(block12 <= 0.05){
  document.getElementById("BlockImg12").src = "Images/Rock.png";
  blocktype12 = 1;
}else if(block12 > 0.05 && block12 <= 0.1){
  document.getElementById("BlockImg12").src = "Images/Bamboo.png";
  blocktype12 = 2;
}else{
  document.getElementById("BlockImg12").src = "Images/Grass.png";
  blocktype12 = 0;
}

if(block13 <= 0.05){
  document.getElementById("BlockImg13").src = "Images/Rock.png";
  blocktype13 = 1;
}else if(block13 > 0.05 && block13 <= 0.1){
  document.getElementById("BlockImg13").src = "Images/Bamboo.png";
  blocktype13 = 2;
}else{
  document.getElementById("BlockImg13").src = "Images/Grass.png";
  blocktype13 = 0;
}

if(block14 <= 0.05){
  document.getElementById("BlockImg14").src = "Images/Rock.png";
  blocktype14 = 1;
}else if(block14 > 0.05 && block14 <= 0.1){
  document.getElementById("BlockImg14").src = "Images/Bamboo.png";
  blocktype14 = 2;
}else{
  document.getElementById("BlockImg14").src = "Images/Grass.png";
  blocktype14 = 0;
}

if(block15 <= 0.05){
  document.getElementById("BlockImg15").src = "Images/Rock.png";
  blocktype15 = 1;
}else if(block15 > 0.05 && block15 <= 0.1){
  document.getElementById("BlockImg15").src = "Images/Bamboo.png";
  blocktype15 = 2;
}else{
  document.getElementById("BlockImg15").src = "Images/Grass.png";
  blocktype15 = 0;
}

if(block16 <= 0.05){
  document.getElementById("BlockImg16").src = "Images/Rock.png";
  blocktype16 = 1;
}else if(block16 > 0.05 && block16 <= 0.1){
  document.getElementById("BlockImg16").src = "Images/Bamboo.png";
  blocktype16 = 2;
}else{
  document.getElementById("BlockImg16").src = "Images/Grass.png";
  blocktype16 = 0;
}

if(block17 <= 0.05){
  document.getElementById("BlockImg17").src = "Images/Rock.png";
  blocktype17 = 1;
}else if(block17 > 0.05 && block17 <= 0.1){
  document.getElementById("BlockImg17").src = "Images/Bamboo.png";
  blocktype17 = 2;
}else{
  document.getElementById("BlockImg17").src = "Images/Grass.png";
  blocktype17 = 0;
}

if(block18 <= 0.05){
  document.getElementById("BlockImg18").src = "Images/Rock.png";
  blocktype18 = 1;
}else if(block18 > 0.05 && block18 <= 0.1){
  document.getElementById("BlockImg18").src = "Images/Bamboo.png";
  blocktype18 = 2;
}else{
  document.getElementById("BlockImg18").src = "Images/Grass.png";
  blocktype18 = 0;
}

if(block19 <= 0.05){
  document.getElementById("BlockImg19").src = "Images/Rock.png";
  blocktype19 = 1;
}else if(block19 > 0.05 && block19 <= 0.1){
  document.getElementById("BlockImg19").src = "Images/Bamboo.png";
  blocktype19 = 2;
}else{
  document.getElementById("BlockImg19").src = "Images/Grass.png";
  blocktype19 = 0;
}

if(block20 <= 0.05){
  document.getElementById("BlockImg20").src = "Images/Rock.png";
  blocktype20 = 1;
}else if(block20 > 0.05 && block20 <= 0.1){
  document.getElementById("BlockImg20").src = "Images/Bamboo.png";
  blocktype20 = 2;
}else{
  document.getElementById("BlockImg20").src = "Images/Grass.png";
  blocktype20 = 0;
}

if(block21 <= 0.05){
  document.getElementById("BlockImg21").src = "Images/Rock.png";
  blocktype21 = 1;
}else if(block21 > 0.05 && block21 <= 0.1){
  document.getElementById("BlockImg21").src = "Images/Bamboo.png";
  blocktype21 = 2;
}else{
  document.getElementById("BlockImg21").src = "Images/Grass.png";
  blocktype21 = 0;
}

if(block22 <= 0.05){
  document.getElementById("BlockImg22").src = "Images/Rock.png";
  blocktype22 = 1;
}else if(block22 > 0.05 && block22 <= 0.1){
  document.getElementById("BlockImg22").src = "Images/Bamboo.png";
  blocktype22 = 2;
}else{
  document.getElementById("BlockImg22").src = "Images/Grass.png";
  blocktype22 = 0;
}

if(block23 <= 0.05){
  document.getElementById("BlockImg23").src = "Images/Rock.png";
  blocktype23 = 1;
}else if(block23 > 0.05 && block23 <= 0.1){
  document.getElementById("BlockImg23").src = "Images/Bamboo.png";
  blocktype23 = 2;
}else{
  document.getElementById("BlockImg23").src = "Images/Grass.png";
  blocktype23 = 0;
}

if(block24 <= 0.05){
  document.getElementById("BlockImg24").src = "Images/Rock.png";
  blocktype24 = 1;
}else if(block24 > 0.05 && block24 <= 0.1){
  document.getElementById("BlockImg24").src = "Images/Bamboo.png";
  blocktype24 = 2;
}else{
  document.getElementById("BlockImg24").src = "Images/Grass.png";
  blocktype24 = 0;
}

if(block25 <= 0.05){
  document.getElementById("BlockImg25").src = "Images/Rock.png";
  blocktype25 = 1;
}else if(block25 > 0.05 && block25 <= 0.1){
  document.getElementById("BlockImg25").src = "Images/Bamboo.png";
  blocktype25 = 2;
}else{
  document.getElementById("BlockImg25").src = "Images/Grass.png";
  blocktype25 = 0;
}

if(block26 <= 0.05){
  document.getElementById("BlockImg26").src = "Images/Rock.png";
  blocktype26 = 1;
}else if(block26 > 0.05 && block26 <= 0.1){
  document.getElementById("BlockImg26").src = "Images/Bamboo.png";
  blocktype26 = 2;
}else{
  document.getElementById("BlockImg26").src = "Images/Grass.png";
  blocktype26 = 0;
}

if(block27 <= 0.05){
  document.getElementById("BlockImg27").src = "Images/Rock.png";
  blocktype27 = 1;
}else if(block27 > 0.05 && block27 <= 0.1){
  document.getElementById("BlockImg27").src = "Images/Bamboo.png";
  blocktype27 = 2;
}else{
  document.getElementById("BlockImg27").src = "Images/Grass.png";
  blocktype27 = 0;
}

if(block28 <= 0.05){
  document.getElementById("BlockImg28").src = "Images/Rock.png";
  blocktype28 = 1;
}else if(block28 > 0.05 && block28 <= 0.1){
  document.getElementById("BlockImg28").src = "Images/Bamboo.png";
  blocktype28 = 2;
}else{
  document.getElementById("BlockImg28").src = "Images/Grass.png";
  blocktype28 = 0;
}

if(block29 <= 0.05){
  document.getElementById("BlockImg29").src = "Images/Rock.png";
  blocktype29 = 1;
}else if(block29 > 0.05 && block29 <= 0.1){
  document.getElementById("BlockImg29").src = "Images/Bamboo.png";
  blocktype29 = 2;
}else{
  document.getElementById("BlockImg29").src = "Images/Grass.png";
  blocktype29 = 0;
}

if(block30 <= 0.05){
  document.getElementById("BlockImg30").src = "Images/Rock.png";
  blocktype30 = 1;
}else if(block30 > 0.05 && block30 <= 0.1){
  document.getElementById("BlockImg30").src = "Images/Bamboo.png";
  blocktype30 = 2;
}else{
  document.getElementById("BlockImg30").src = "Images/Grass.png";
  blocktype30 = 0;
}

if(block31 <= 0.05){
  document.getElementById("BlockImg31").src = "Images/Rock.png";
  blocktype31 = 1;
}else if(block31 > 0.05 && block31 <= 0.1){
  document.getElementById("BlockImg31").src = "Images/Bamboo.png";
  blocktype31 = 2;
}else{
  document.getElementById("BlockImg31").src = "Images/Grass.png";
  blocktype31 = 0;
}

if(block32 <= 0.05){
  document.getElementById("BlockImg32").src = "Images/Rock.png";
  blocktype32 = 1;
}else if(block32 > 0.05 && block32 <= 0.1){
  document.getElementById("BlockImg32").src = "Images/Bamboo.png";
  blocktype32 = 2;
}else{
  document.getElementById("BlockImg32").src = "Images/Grass.png";
  blocktype32 = 0;
}

if(block33 <= 0.05){
  document.getElementById("BlockImg33").src = "Images/Rock.png";
  blocktype33 = 1;
}else if(block33 > 0.05 && block33 <= 0.1){
  document.getElementById("BlockImg33").src = "Images/Bamboo.png";
  blocktype33 = 2;
}else{
  document.getElementById("BlockImg33").src = "Images/Grass.png";
  blocktype33 = 0;
}

if(block34 <= 0.05){
  document.getElementById("BlockImg34").src = "Images/Rock.png";
  blocktype34 = 1;
}else if(block34 > 0.05 && block34 <= 0.1){
  document.getElementById("BlockImg34").src = "Images/Bamboo.png";
  blocktype34 = 2;
}else{
  document.getElementById("BlockImg34").src = "Images/Grass.png";
  blocktype34 = 0;
}

document.getElementById("BlockImg35").src = "Images/PlayerFront.png";
blocktype35 = 0;

if(block36 <= 0.05){
  document.getElementById("BlockImg36").src = "Images/Rock.png";
  blocktype36 = 1;
}else if(block36 > 0.05 && block36 <= 0.1){
  document.getElementById("BlockImg36").src = "Images/Bamboo.png";
  blocktype36 = 2;
}else{
  document.getElementById("BlockImg36").src = "Images/Grass.png";
  blocktype36 = 0;
}

if(block37 <= 0.05){
  document.getElementById("BlockImg37").src = "Images/Rock.png";
  blocktype37 = 1;
}else if(block37 > 0.05 && block37 <= 0.1){
  document.getElementById("BlockImg37").src = "Images/Bamboo.png";
  blocktype37 = 2;
}else{
  document.getElementById("BlockImg37").src = "Images/Grass.png";
  blocktype37 = 0;
}

if(block38 <= 0.05){
  document.getElementById("BlockImg38").src = "Images/Rock.png";
  blocktype38 = 1;
}else if(block38 > 0.05 && block38 <= 0.1){
  document.getElementById("BlockImg38").src = "Images/Bamboo.png";
  blocktype38 = 2;
}else{
  document.getElementById("BlockImg38").src = "Images/Grass.png";
  blocktype38 = 0;
}

if(block39 <= 0.05){
  document.getElementById("BlockImg39").src = "Images/Rock.png";
  blocktype39 = 1;
}else if(block39 > 0.05 && block39 <= 0.1){
  document.getElementById("BlockImg39").src = "Images/Bamboo.png";
  blocktype39 = 2;
}else{
  document.getElementById("BlockImg39").src = "Images/Grass.png";
  blocktype39 = 0;
}

if(block40 <= 0.05){
  document.getElementById("BlockImg40").src = "Images/Rock.png";
  blocktype40 = 1;
}else if(block40 > 0.05 && block40 <= 0.1){
  document.getElementById("BlockImg40").src = "Images/Bamboo.png";
  blocktype40 = 2;
}else{
  document.getElementById("BlockImg40").src = "Images/Grass.png";
  blocktype40 = 0;
}

if(block41 <= 0.05){
  document.getElementById("BlockImg41").src = "Images/Rock.png";
  blocktype41 = 1;
}else if(block41 > 0.05 && block41 <= 0.1){
  document.getElementById("BlockImg41").src = "Images/Bamboo.png";
  blocktype41 = 2;
}else{
  document.getElementById("BlockImg41").src = "Images/Grass.png";
  blocktype41 = 0;
}

if(block42 <= 0.05){
  document.getElementById("BlockImg42").src = "Images/Rock.png";
  blocktype42 = 1;
}else if(block42 > 0.05 && block42 <= 0.1){
  document.getElementById("BlockImg42").src = "Images/Bamboo.png";
  blocktype42 = 2;
}else{
  document.getElementById("BlockImg42").src = "Images/Grass.png";
  blocktype42 = 0;
}

if(block43 <= 0.05){
  document.getElementById("BlockImg43").src = "Images/Rock.png";
  blocktype43 = 1;
}else if(block43 > 0.05 && block43 <= 0.1){
  document.getElementById("BlockImg43").src = "Images/Bamboo.png";
  blocktype43 = 2;
}else{
  document.getElementById("BlockImg43").src = "Images/Grass.png";
  blocktype43 = 0;
}

if(block44 <= 0.05){
  document.getElementById("BlockImg44").src = "Images/Rock.png";
  blocktype44 = 1;
}else if(block44 > 0.05 && block44 <= 0.1){
  document.getElementById("BlockImg44").src = "Images/Bamboo.png";
  blocktype44 = 2;
}else{
  document.getElementById("BlockImg44").src = "Images/Grass.png";
  blocktype44 = 0;
}

if(block45 <= 0.05){
  document.getElementById("BlockImg45").src = "Images/Rock.png";
  blocktype45 = 1;
}else if(block45 > 0.05 && block45 <= 0.1){
  document.getElementById("BlockImg45").src = "Images/Bamboo.png";
  blocktype45 = 2;
}else{
  document.getElementById("BlockImg45").src = "Images/Grass.png";
  blocktype45 = 0;
}

if(block46 <= 0.05){
  document.getElementById("BlockImg46").src = "Images/Rock.png";
  blocktype46 = 1;
}else if(block46 > 0.05 && block46 <= 0.1){
  document.getElementById("BlockImg46").src = "Images/Bamboo.png";
  blocktype46 = 2;
}else{
  document.getElementById("BlockImg46").src = "Images/Grass.png";
  blocktype46 = 0;
}

if(block47 <= 0.05){
  document.getElementById("BlockImg47").src = "Images/Rock.png";
  blocktype47 = 1;
}else if(block47 > 0.05 && block47 <= 0.1){
  document.getElementById("BlockImg47").src = "Images/Bamboo.png";
  blocktype47 = 2;
}else{
  document.getElementById("BlockImg47").src = "Images/Grass.png";
  blocktype47 = 0;
}

if(block48 <= 0.05){
  document.getElementById("BlockImg48").src = "Images/Rock.png";
  blocktype48 = 1;
}else if(block48 > 0.05 && block48 <= 0.1){
  document.getElementById("BlockImg48").src = "Images/Bamboo.png";
  blocktype48 = 2;
}else{
  document.getElementById("BlockImg48").src = "Images/Grass.png";
  blocktype48 = 0;
}

if(block49 <= 0.05){
  document.getElementById("BlockImg49").src = "Images/Rock.png";
  blocktype49 = 1;
}else if(block49 > 0.05 && block49 <= 0.1){
  document.getElementById("BlockImg49").src = "Images/Bamboo.png";
  blocktype49 = 2;
}else{
  document.getElementById("BlockImg49").src = "Images/Grass.png";
  blocktype49 = 0;
}

if(block50 <= 0.05){
  document.getElementById("BlockImg50").src = "Images/Rock.png";
  blocktype50 = 1;
}else if(block50 > 0.05 && block50 <= 0.1){
  document.getElementById("BlockImg50").src = "Images/Bamboo.png";
  blocktype50 = 2;
}else{
  document.getElementById("BlockImg50").src = "Images/Grass.png";
  blocktype50 = 0;
}

if(block51 <= 0.05){
  document.getElementById("BlockImg51").src = "Images/Rock.png";
  blocktype51 = 1;
}else if(block51 > 0.05 && block51 <= 0.1){
  document.getElementById("BlockImg51").src = "Images/Bamboo.png";
  blocktype51 = 2;
}else{
  document.getElementById("BlockImg51").src = "Images/Grass.png";
  blocktype51 = 0;
}

if(block52 <= 0.05){
  document.getElementById("BlockImg52").src = "Images/Rock.png";
  blocktype52 = 1;
}else if(block52 > 0.05 && block52 <= 0.1){
  document.getElementById("BlockImg52").src = "Images/Bamboo.png";
  blocktype52 = 2;
}else{
  document.getElementById("BlockImg52").src = "Images/Grass.png";
  blocktype52 = 0;
}

if(block53 <= 0.05){
  document.getElementById("BlockImg53").src = "Images/Rock.png";
  blocktype53 = 1;
}else if(block53 > 0.05 && block53 <= 0.1){
  document.getElementById("BlockImg53").src = "Images/Bamboo.png";
  blocktype53 = 2;
}else{
  document.getElementById("BlockImg53").src = "Images/Grass.png";
  blocktype53 = 0;
}

if(block54 <= 0.05){
  document.getElementById("BlockImg54").src = "Images/Rock.png";
  blocktype54 = 1;
}else if(block54 > 0.05 && block54 <= 0.1){
  document.getElementById("BlockImg54").src = "Images/Bamboo.png";
  blocktype54 = 2;
}else{
  document.getElementById("BlockImg54").src = "Images/Grass.png";
  blocktype54 = 0;
}

if(block55 <= 0.05){
  document.getElementById("BlockImg55").src = "Images/Rock.png";
  blocktype55 = 1;
}else if(block55 > 0.05 && block55 <= 0.1){
  document.getElementById("BlockImg55").src = "Images/Bamboo.png";
  blocktype55 = 2;
}else{
  document.getElementById("BlockImg55").src = "Images/Grass.png";
  blocktype55 = 0;
}

if(block56 <= 0.05){
  document.getElementById("BlockImg56").src = "Images/Rock.png";
  blocktype56 = 1;
}else if(block56 > 0.05 && block56 <= 0.1){
  document.getElementById("BlockImg56").src = "Images/Bamboo.png";
  blocktype56 = 2;
}else{
  document.getElementById("BlockImg56").src = "Images/Grass.png";
  blocktype56 = 0;
}

if(block57 <= 0.05){
  document.getElementById("BlockImg57").src = "Images/Rock.png";
  blocktype57 = 1;
}else if(block57 > 0.05 && block57 <= 0.1){
  document.getElementById("BlockImg57").src = "Images/Bamboo.png";
  blocktype57 = 2;
}else{
  document.getElementById("BlockImg57").src = "Images/Grass.png";
  blocktype57 = 0;
}

if(block58 <= 0.05){
  document.getElementById("BlockImg58").src = "Images/Rock.png";
  blocktype58 = 1;
}else if(block58 > 0.05 && block58 <= 0.1){
  document.getElementById("BlockImg58").src = "Images/Bamboo.png";
  blocktype58 = 2;
}else{
  document.getElementById("BlockImg58").src = "Images/Grass.png";
  blocktype58 = 0;
}

if(block59 <= 0.05){
  document.getElementById("BlockImg59").src = "Images/Rock.png";
  blocktype59 = 1;
}else if(block59 > 0.05 && block59 <= 0.1){
  document.getElementById("BlockImg59").src = "Images/Bamboo.png";
  blocktype59 = 2;
}else{
  document.getElementById("BlockImg59").src = "Images/Grass.png";
  blocktype59 = 0;
}

if(block60 <= 0.05){
  document.getElementById("BlockImg60").src = "Images/Rock.png";
  blocktype60 = 1;
}else if(block60 > 0.05 && block60 <= 0.1){
  document.getElementById("BlockImg60").src = "Images/Bamboo.png";
  blocktype60 = 2;
}else{
  document.getElementById("BlockImg60").src = "Images/Grass.png";
  blocktype60 = 0;
}

if(block61 <= 0.05){
  document.getElementById("BlockImg61").src = "Images/Rock.png";
  blocktype61 = 1;
}else if(block61 > 0.05 && block61 <= 0.1){
  document.getElementById("BlockImg61").src = "Images/Bamboo.png";
  blocktype61 = 2;
}else{
  document.getElementById("BlockImg61").src = "Images/Grass.png";
  blocktype61 = 0;
}

if(block62 <= 0.05){
  document.getElementById("BlockImg62").src = "Images/Rock.png";
  blocktype62 = 1;
}else if(block62 > 0.05 && block62 <= 0.1){
  document.getElementById("BlockImg62").src = "Images/Bamboo.png";
  blocktype62 = 2;
}else{
  document.getElementById("BlockImg62").src = "Images/Grass.png";
  blocktype62 = 0;
}

if(block63 <= 0.05){
  document.getElementById("BlockImg63").src = "Images/Rock.png";
  blocktype63 = 1;
}else if(block63 > 0.05 && block63 <= 0.1){
  document.getElementById("BlockImg63").src = "Images/Bamboo.png";
  blocktype63 = 2;
}else{
  document.getElementById("BlockImg63").src = "Images/Grass.png";
  blocktype63 = 0;
}

if(block64 <= 0.05){
  document.getElementById("BlockImg64").src = "Images/Rock.png";
  blocktype64 = 1;
}else if(block64 > 0.05 && block64 <= 0.1){
  document.getElementById("BlockImg64").src = "Images/Bamboo.png";
  blocktype64 = 2;
}else{
  document.getElementById("BlockImg64").src = "Images/Grass.png";
  blocktype64 = 0;
}

if(block65 <= 0.05){
  document.getElementById("BlockImg65").src = "Images/Rock.png";
  blocktype65 = 1;
}else if(block65 > 0.05 && block65 <= 0.1){
  document.getElementById("BlockImg65").src = "Images/Bamboo.png";
  blocktype65 = 2;
}else{
  document.getElementById("BlockImg65").src = "Images/Grass.png";
  blocktype65 = 0;
}

if(block66 <= 0.05){
  document.getElementById("BlockImg66").src = "Images/Rock.png";
  blocktype66 = 1;
}else if(block66 > 0.05 && block66 <= 0.1){
  document.getElementById("BlockImg66").src = "Images/Bamboo.png";
  blocktype66 = 2;
}else{
  document.getElementById("BlockImg66").src = "Images/Grass.png";
  blocktype66 = 0;
}

if(block67 <= 0.05){
  document.getElementById("BlockImg67").src = "Images/Rock.png";
  blocktype67 = 1;
}else if(block67 > 0.05 && block67 <= 0.1){
  document.getElementById("BlockImg67").src = "Images/Bamboo.png";
  blocktype67 = 2;
}else{
  document.getElementById("BlockImg67").src = "Images/Grass.png";
  blocktype67 = 0;
}

if(block68 <= 0.05){
  document.getElementById("BlockImg68").src = "Images/Rock.png";
  blocktype68 = 1;
}else if(block68 > 0.05 && block68 <= 0.1){
  document.getElementById("BlockImg68").src = "Images/Bamboo.png";
  blocktype68 = 2;
}else{
  document.getElementById("BlockImg68").src = "Images/Grass.png";
  blocktype68 = 0;
}

if(block69 <= 0.05){
  document.getElementById("BlockImg69").src = "Images/Rock.png";
  blocktype69 = 1;
}else if(block69 > 0.05 && block69 <= 0.1){
  document.getElementById("BlockImg69").src = "Images/Bamboo.png";
  blocktype69 = 2;
}else{
  document.getElementById("BlockImg69").src = "Images/Grass.png";
  blocktype69 = 0;
}

if(block70 <= 0.05){
  document.getElementById("BlockImg70").src = "Images/Rock.png";
  blocktype70 = 1;
}else if(block70 > 0.05 && block70 <= 0.1){
  document.getElementById("BlockImg70").src = "Images/Bamboo.png";
  blocktype70 = 2;
}else{
  document.getElementById("BlockImg70").src = "Images/Grass.png";
  blocktype70 = 0;
}

function Left(){
  if(eval("blocktype" + pos) == 0){
    if((pos != 1) && (pos != 11) && (pos != 21) && (pos != 31) && (pos != 41) && (pos != 51) && (pos != 61)){
      direction = 1;
      number = pos - 1;
      if(eval("blocktype" + number) == 0){
        id = "BlockImg" + pos;
        document.getElementById(id).src = "Images/Grass.png";
        pos = number;
        id = "BlockImg" + pos;
        document.getElementById(id).src = "Images/PlayerLeft.png";
      }else if(eval("blocktype" + number) == 8){
        topath = 1;
        frompath = 0;
        WalkPathLeft();
      }else{
        id = "BlockImg" + pos;
        document.getElementById(id).src = "Images/PlayerLeft.png";
      }
    }else{
      id = "BlockImg" + pos;
      direction = 1;
      document.getElementById(id).src = "Images/PlayerLeft.png";
    }
  }else if(eval("blocktype" + pos) == 8){
    if((pos != 1) && (pos != 11) && (pos != 21) && (pos != 31) && (pos != 41) && (pos != 51) && (pos != 61)){
      direction = 1;
      number = pos - 1;
      if(eval("blocktype" + number) == 0){
        topath = 0;
        frompath = 1;
        WalkPathLeft();
      }else if(eval("blocktype" + number) == 8){
        topath = 1;
        frompath = 1;
        WalkPathLeft();
      }else{
        topath = 2;
        WalkPathLeft();
      }
    }
  }else if((eval("blocktype" + pos) == 208) || (eval("blocktype" + pos) == 209) || (eval("blocktype" + pos) == 210)){
    direction = 1;
    value = 207;
    eval("blocktype" + pos + "=" + value);
    id = "BlockImg" + pos;
    document.getElementById(id).src = "Images/HouseWithPSide.png"
  }
  console.log(pos);
}

function Up(){
  if(eval("blocktype" + pos) == 0){
    if((pos != 1) && (pos != 2) && (pos != 3) && (pos != 4) && (pos != 5) && (pos != 6) && (pos != 7) && (pos != 8) && (pos != 9) && (pos != 10)){
      direction = 2;
      number = pos - 10;
      if(eval("blocktype" + number) == 0){
        id = "BlockImg" + pos;
        document.getElementById(id).src = "Images/Grass.png";
        pos = number;
        id = "BlockImg" + pos;
        document.getElementById(id).src = "Images/PlayerBack.png";
      }else if(eval("blocktype" + number) == 8){
        topath = 1;
        frompath = 0;
        WalkPathUp();
      }else if(eval("blocktype" + number) == 206){
        WalkInHouse();
      }else{
        id = "BlockImg" + pos;
        document.getElementById(id).src = "Images/PlayerBack.png";
      }
    }else{
      id = "BlockImg" + pos;
      direction = 2;
      document.getElementById(id).src = "Images/PlayerBack.png";
    }
  }else if(eval("blocktype" + pos) == 8){
    if((pos != 1) && (pos != 2) && (pos != 3) && (pos != 4) && (pos != 5) && (pos != 6) && (pos != 7) && (pos != 8) && (pos != 9) && (pos != 10)){
      direction = 2;
      number = pos - 10;
      if(eval("blocktype" + number) == 0){
        topath = 0;
        frompath = 1;
        WalkPathUp();
      }else if(eval("blocktype" + number) == 8){
        topath = 1;
        frompath = 1;
        WalkPathUp();
      }else if(eval("blocktype" + number) == 206){
        WalkInHouse();
      }else{
        topath = 2;
        WalkPathUp();
      }
    }
  }else if((eval("blocktype" + pos) == 207) || (eval("blocktype" + pos) == 209) || (eval("blocktype" + pos) == 210)){
    direction = 2;
    value = 208;
    eval("blocktype" + pos + "=" + value);
    id = "BlockImg" + pos;
    document.getElementById(id).src = "Images/HouseWithPFront.png"
  }
  console.log(pos);
}

function Right(){
  if(eval("blocktype" + pos) == 0){
    if((pos != 10) && (pos != 20) && (pos != 30) && (pos != 40) && (pos != 50) && (pos != 60) && (pos != 70)){
      direction = 3;
      number = pos + 1;
      if(eval("blocktype" + number) == 0){
        id = "BlockImg" + pos;
        document.getElementById(id).src = "Images/Grass.png";
        pos = number;
        id = "BlockImg" + pos;
        document.getElementById(id).src = "Images/PlayerRight.png";
      }else if(eval("blocktype" + number) == 8){
        topath = 1;
        frompath = 0;
        WalkPathRight();
      }else{
        id = "BlockImg" + pos;
        document.getElementById(id).src = "Images/PlayerRight.png";
      }
    }else{
      id = "BlockImg" + pos;
      direction = 3;
      document.getElementById(id).src = "Images/PlayerRight.png";
    }
  }else if(eval("blocktype" + pos) == 8){
    if((pos != 10) && (pos != 20) && (pos != 30) && (pos != 40) && (pos != 50) && (pos != 60) && (pos != 70)){
      direction = 3;
      number = pos + 1;
      if(eval("blocktype" + number) == 0){
        topath = 0;
        frompath = 1;
        WalkPathRight();
      }else if(eval("blocktype" + number) == 8){
        topath = 1;
        frompath = 1;
        WalkPathRight();
      }else{
        topath = 2;
        WalkPathRight();
      }
    }
  }else if((eval("blocktype" + pos) == 207) || (eval("blocktype" + pos) == 208) || (eval("blocktype" + pos) == 210)){
    direction = 3;
    value = 207;
    eval("blocktype" + pos + "=" + value);
    id = "BlockImg" + pos;
    document.getElementById(id).src = "Images/HouseWithPSide.png"
  }
  console.log(pos);
}

function Down(){
  if(eval("blocktype" + pos) == 0){
    if((pos != 61) && (pos != 62) && (pos != 63) && (pos != 64) && (pos != 65) && (pos != 66) && (pos != 67) && (pos != 68) && (pos != 69) && (pos != 70)){
      direction = 4;
      number = pos + 10;
      if(eval("blocktype" + number) == 0){
        id = "BlockImg" + pos;
        document.getElementById(id).src = "Images/Grass.png";
        pos = number;
        id = "BlockImg" + pos;
        document.getElementById(id).src = "Images/PlayerFront.png";
      }else if(eval("blocktype" + number) == 8){
        topath = 1;
        frompath = 0;
        WalkPathDown();
      }else{
        id = "BlockImg" + pos;
        document.getElementById(id).src = "Images/PlayerFront.png";
      }
    }else{
      id = "BlockImg" + pos;
      direction = 4;
      document.getElementById(id).src = "Images/PlayerFront.png";
    }
  }else if(eval("blocktype" + pos) == 8){
    if((pos != 61) && (pos != 62) && (pos != 63) && (pos != 64) && (pos != 65) && (pos != 66) && (pos != 67) && (pos != 68) && (pos != 69) && (pos != 70)){
      direction = 4;
      number = pos + 10;
      if(eval("blocktype" + number) == 0){
        topath = 0;
        frompath = 1;
        WalkPathDown();
      }else if(eval("blocktype" + number) == 8){
        topath = 1;
        frompath = 1;
        WalkPathDown();
      }else{
        topath = 2;
        WalkPathDown();
      }
    }
  }else if((eval("blocktype" + pos) == 207) || (eval("blocktype" + pos) == 208) || (eval("blocktype" + pos) == 209) || (eval("blocktype" + pos) == 210)){
    WalkOutHouse();
  }
  console.log(pos);
}

function Space(){
  console.log("Space");
  if(direction == 1){
    if((pos != 1) && (pos != 11) && (pos != 21) && (pos != 31) && (pos != 41) && (pos != 51) && (pos != 61)){
      number = pos - 1;
      if(eval("blocktype" + number) == 1){
        itemtoget = 1;
        CheckItems();
      }else if(eval("blocktype" + number) == 2){
        itemtoget = 2;
        CheckItems();
      }
    }
  }else if(direction == 2){
    if((pos != 1) && (pos != 2) && (pos != 3) && (pos != 4) && (pos != 5) && (pos != 6) && (pos != 7) && (pos != 8) && (pos != 9) && (pos != 10)){
      number = pos - 10;
      if(eval("blocktype" + number) == 1){
        itemtoget = 1;
        CheckItems();
      }else if(eval("blocktype" + number) == 2){
        itemtoget = 2;
        CheckItems();
      }
    }
  }else if(direction == 3){
    if((pos != 10) && (pos != 20) && (pos != 30) && (pos != 40) && (pos != 50) && (pos != 60) && (pos != 70)){
      number = pos + 1;
      if(eval("blocktype" + number) == 1){
        itemtoget = 1;
        CheckItems();
      }else if(eval("blocktype" + number) == 2){
        itemtoget = 2;
        CheckItems();
      }
    }
  }else if(direction == 4){
    if((pos != 61) && (pos != 62) && (pos != 63) && (pos != 64) && (pos != 65) && (pos != 66) && (pos != 67) && (pos != 68) && (pos != 69) && (pos != 70)){
      number = pos + 10;
      if(eval("blocktype" + number) == 1){
        itemtoget = 1;
        CheckItems();
      }else if(eval("blocktype" + number) == 2){
        itemtoget = 2;
        CheckItems();
      }
    }
  }
}

function CheckItems(){
  if(itemslot1 == 0){
    if(itemtoget == 1){
      itemtoget = 0;
      document.getElementById("Item1").src = "Images/RockItem.png";
      itemslot1 = 1;
      document.getElementById("ItemName1").innerHTML = "Rock";
      rock += 1;
    }else if(itemtoget == 2){
      itemtoget = 0;
      document.getElementById("Item1").src = "Images/BambooItem.png";
      itemslot1 = 2;
      document.getElementById("ItemName1").innerHTML = "Bamboo";
      bamboo += 1;
    }
  }else if(itemslot2 == 0){
    if(itemtoget == 1){
      itemtoget = 0;
      document.getElementById("Item2").src = "Images/RockItem.png";
      itemslot2 = 1;
      document.getElementById("ItemName2").innerHTML = "Rock";
      rock += 1;
    }else if(itemtoget == 2){
      itemtoget = 0;
      document.getElementById("Item2").src = "Images/BambooItem.png";
      itemslot2 = 2;
      document.getElementById("ItemName2").innerHTML = "Bamboo";
      bamboo += 1;
    }
  }else if(itemslot3 == 0){
    if(itemtoget == 1){
      itemtoget = 0;
      document.getElementById("Item3").src = "Images/RockItem.png";
      itemslot3 = 1;
      document.getElementById("ItemName3").innerHTML = "Rock";
      rock += 1;
    }else if(itemtoget == 2){
      itemtoget = 0;
      document.getElementById("Item3").src = "Images/BambooItem.png";
      itemslot3 = 2;
      document.getElementById("ItemName3").innerHTML = "Bamboo";
      bamboo += 1;
    }
  }else if(itemslot4 == 0){
    if(itemtoget == 1){
      itemtoget = 0;
      document.getElementById("Item4").src = "Images/RockItem.png";
      itemslot4 = 1;
      document.getElementById("ItemName4").innerHTML = "Rock";
      rock += 1;
    }else if(itemtoget == 2){
      itemtoget = 0;
      document.getElementById("Item4").src = "Images/BambooItem.png";
      itemslot4 = 2;
      document.getElementById("ItemName4").innerHTML = "Bamboo";
      bamboo += 1;
    }
  }else{
    nothing = 1;
  }
}

function ItemUse1(){
  if(itemslot1 != 0){
    if(itemslot1 == 1){
      if(deleter == 1){
        itemslot1 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        rock -= 1;
        document.getElementById('Item1').src = "";
      }
    }else if(itemslot1 == 2){
      if(deleter == 1){
        itemslot1 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        bamboo -= 1;
        document.getElementById('Item1').src = "";
      }
    }else if(itemslot1 == 3){
      if(deleter == 1){
        itemslot1 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        campfire -= 1;
        document.getElementById('Item1').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 0){
            itemslot1 = 0;
            document.getElementById("ItemName1").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item1').src = "";
            value = 3;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 0){
            itemslot1 = 0;
            document.getElementById("ItemName1").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item1').src = "";
            value = 3;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 0){
            itemslot1 = 0;
            document.getElementById("ItemName1").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item1').src = "";
            value = 3;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 0){
            itemslot1 = 0;
            document.getElementById("ItemName1").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item1').src = "";
            value = 3;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }
      }
    }else if(itemslot1 == 4){
      if(deleter == 1){
        itemslot1 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        fire -= 1;
        document.getElementById('Item1').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 3){
            itemslot1 = 0;
            document.getElementById("ItemName1").innerHTML = "";
            fire -= 1;
            document.getElementById('Item1').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 3){
            itemslot1 = 0;
            document.getElementById("ItemName1").innerHTML = "";
            fire -= 1;
            document.getElementById('Item1').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 3){
            itemslot1 = 0;
            document.getElementById("ItemName1").innerHTML = "";
            fire -= 1;
            document.getElementById('Item1').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 3){
            itemslot1 = 0;
            document.getElementById("ItemName1").innerHTML = "";
            fire -= 1;
            document.getElementById('Item1').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }
      }
    }else if(itemslot1 == 5){
      if(deleter == 1){
        itemslot1 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        sickle -= 1;
        document.getElementById('Item1').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
              console.log("Slot1");
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
              console.log("Slot2");
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
              console.log("Slot3");
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
              console.log("Slot4");
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }else if(eval("blocktype" + number) == 205){
            AddDoor();
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }
      }
    }else if(itemslot1 == 6){
      if(deleter == 1){
        itemslot1 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        leaf -= 1;
        document.getElementById('Item1').src = "";
      }
    }else if(itemslot1 == 7){
      if(deleter == 1){
        itemslot1 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        tent -= 1;
        document.getElementById('Item1').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 0){
            itemslot1 = 0;
            document.getElementById("ItemName1").innerHTML = "";
            tent -= 1;
            document.getElementById('Item1').src = "";
            value = 7;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/Tent.png";
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 0){
            itemslot1 = 0;
            document.getElementById("ItemName1").innerHTML = "";
            tent -= 1;
            document.getElementById('Item1').src = "";
            value = 7;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/Tent.png";
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 0){
            itemslot1 = 0;
            document.getElementById("ItemName1").innerHTML = "";
            tent -= 1;
            document.getElementById('Item1').src = "";
            value = 7;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/Tent.png";
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 0){
            itemslot1 = 0;
            document.getElementById("ItemName1").innerHTML = "";
            tent -= 1;
            document.getElementById('Item1').src = "";
            value = 7;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/Tent.png";
          }
        }
      }
    }else if(itemslot1 == 8){
      if(deleter == 1){
        itemslot1 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        shovel -= 1;
        document.getElementById('Item1').src = "";
      }else if(deleter == 0){
        PathChecker();
      }
    }else if(itemslot1 == 9){
      if(deleter == 1){
        itemslot1 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        wall -= 1;
        document.getElementById('Item1').src = "";
      }else if(deleter == 0){
        BuildHouse();
      }
    }else if(itemslot1 == 10){
      if(deleter == 1){
        itemslot1 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        leafstick -= 1;
        document.getElementById('Item1').src = "";
      }
    }else if(itemslot1 == 11){
      if(deleter == 1){
        itemslot1 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        roof -= 1;
        document.getElementById('Item1').src = "";
      }else if(deleter == 0){
        AddRoof();
      }
    }
  }
}

function ItemUse2(){
  if(itemslot2 != 0){
    if(itemslot2 == 1){
      if(deleter == 1){
        itemslot2 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        rock -= 1;
        document.getElementById('Item2').src = "";
      }
    }else if(itemslot2 == 2){
      if(deleter == 1){
        itemslot2 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        bamboo -= 1;
        document.getElementById('Item2').src = "";
      }
    }else if(itemslot2 == 3){
      if(deleter == 1){
        itemslot2 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        campfire -= 1;
        document.getElementById('Item2').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 0){
            itemslot2 = 0;
            document.getElementById("ItemName2").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item2').src = "";
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 0){
            itemslot2 = 0;
            document.getElementById("ItemName2").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item2').src = "";
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 0){
            itemslot2 = 0;
            document.getElementById("ItemName2").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item2').src = "";
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 0){
            itemslot2 = 0;
            document.getElementById("ItemName2").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item2').src = "";
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }
      }
    }else if(itemslot2 == 4){
      if(deleter == 1){
        itemslot2 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        fire -= 1;
        document.getElementById('Item2').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 3){
            itemslot2 = 0;
            document.getElementById("ItemName2").innerHTML = "";
            fire -= 1;
            document.getElementById('Item2').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 3){
            itemslot2 = 0;
            document.getElementById("ItemName2").innerHTML = "";
            fire -= 1;
            document.getElementById('Item2').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 3){
            itemslot2 = 0;
            document.getElementById("ItemName2").innerHTML = "";
            fire -= 1;
            document.getElementById('Item2').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 3){
            itemslot2 = 0;
            document.getElementById("ItemName2").innerHTML = "";
            fire -= 1;
            document.getElementById('Item2').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }
      }
    }else if(itemslot2 == 5){
      if(deleter == 1){
        itemslot2 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        sickle -= 1;
        document.getElementById('Item2').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }else if(eval("blocktype" + number) == 205){
            AddDoor();
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }
      }
    }else if(itemslot2 == 6){
      if(deleter == 1){
        itemslot2 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        leaf -= 1;
        document.getElementById('Item2').src = "";
      }
    }else if(itemslot2 == 8){
      if(deleter == 1){
        itemslot2 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        shovel -= 1;
        document.getElementById('Item2').src = "";
      }else if(deleter == 0){
        PathChecker();
      }
    }else if(itemslot2 == 10){
      if(deleter == 1){
        itemslot2 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        leafstick -= 1;
        document.getElementById('Item2').src = "";
      }
    }
  }
}

function ItemUse3(){
  if(itemslot3 != 0){
    if(itemslot3 == 1){
      if(deleter == 1){
        itemslot3 = 0;
        document.getElementById("ItemName3").innerHTML = "";
        rock -= 1;
        document.getElementById('Item3').src = "";
      }
    }else if(itemslot3 == 2){
      if(deleter == 1){
        itemslot3 = 0;
        document.getElementById("ItemName3").innerHTML = "";
        bamboo -= 1;
        document.getElementById('Item3').src = "";
      }
    }else if(itemslot3 == 3){
      if(deleter == 1){
        itemslot3 = 0;
        document.getElementById("ItemName3").innerHTML = "";
        campfire -= 1;
        document.getElementById('Item3').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 0){
            itemslot3 = 0;
            document.getElementById("ItemName3").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item3').src = "";
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 0){
            itemslot3 = 0;
            document.getElementById("ItemName3").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item3').src = "";
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 0){
            itemslot3 = 0;
            document.getElementById("ItemName3").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item3').src = "";
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 0){
            itemslot3 = 0;
            document.getElementById("ItemName3").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item3').src = "";
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }
      }
    }else if(itemslot3 == 4){
      if(deleter == 1){
        itemslot3 = 0;
        document.getElementById("ItemName3").innerHTML = "";
        fire -= 1;
        document.getElementById('Item3').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 3){
            itemslot3 = 0;
            document.getElementById("ItemName3").innerHTML = "";
            fire -= 1;
            document.getElementById('Item3').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 3){
            itemslot3 = 0;
            document.getElementById("ItemName3").innerHTML = "";
            fire -= 1;
            document.getElementById('Item3').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 3){
            itemslot3 = 0;
            document.getElementById("ItemName3").innerHTML = "";
            fire -= 1;
            document.getElementById('Item3').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 3){
            itemslot3 = 0;
            document.getElementById("ItemName3").innerHTML = "";
            fire -= 1;
            document.getElementById('Item3').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }
      }
    }else if(itemslot3 == 5){
      if(deleter == 1){
        itemslot3 = 0;
        document.getElementById("ItemName3").innerHTML = "";
        sickle -= 1;
        document.getElementById('Item3').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }else if(eval("blocktype" + number) == 205){
            AddDoor();
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }
      }
    }else if(itemslot3 == 6){
      if(deleter == 1){
        itemslot3 = 0;
        document.getElementById("ItemName3").innerHTML = "";
        leaf -= 1;
        document.getElementById('Item3').src = "";
      }
    }else if(itemslot3 == 8){
      if(deleter == 1){
        itemslot3 = 0;
        document.getElementById("ItemName3").innerHTML = "";
        shovel -= 1;
        document.getElementById('Item3').src = "";
      }else if(deleter == 0){
        PathChecker();
      }
    }else if(itemslot3 == 10){
      if(deleter == 1){
        itemslot3 = 0;
        document.getElementById("ItemName3").innerHTML = "";
        leafstick -= 1;
        document.getElementById('Item3').src = "";
      }
    }
  }
}

function ItemUse4(){
  if(itemslot4 != 0){
    if(itemslot4 == 1){
      if(deleter == 1){
        itemslot4 = 0;
        document.getElementById("ItemName4").innerHTML = "";
        rock -= 1;
        document.getElementById('Item4').src = "";
      }
    }else if(itemslot4 == 2){
      if(deleter == 1){
        itemslot4 = 0;
        document.getElementById("ItemName4").innerHTML = "";
        bamboo -= 1;
        document.getElementById('Item4').src = "";
      }
    }else if(itemslot4 == 3){
      if(deleter == 1){
        itemslot4 = 0;
        document.getElementById("ItemName4").innerHTML = "";
        campfire -= 1;
        document.getElementById('Item4').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 0){
            itemslot4 = 0;
            document.getElementById("ItemName4").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item4').src = "";
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 0){
            itemslot4 = 0;
            document.getElementById("ItemName4").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item4').src = "";
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 0){
            itemslot4 = 0;
            document.getElementById("ItemName4").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item4').src = "";
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 0){
            itemslot4 = 0;
            document.getElementById("ItemName4").innerHTML = "";
            campfire -= 1;
            document.getElementById('Item4').src = "";
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOff.png";
          }
        }
      }
    }else if(itemslot4 == 4){
      if(deleter == 1){
        itemslot4 = 0;
        document.getElementById("ItemName4").innerHTML = "";
        fire -= 1;
        document.getElementById('Item4').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 3){
            itemslot4 = 0;
            document.getElementById("ItemName4").innerHTML = "";
            fire -= 1;
            document.getElementById('Item4').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 3){
            itemslot4 = 0;
            document.getElementById("ItemName4").innerHTML = "";
            fire -= 1;
            document.getElementById('Item4').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 3){
            itemslot4 = 0;
            document.getElementById("ItemName4").innerHTML = "";
            fire -= 1;
            document.getElementById('Item4').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 3){
            itemslot4 = 0;
            document.getElementById("ItemName4").innerHTML = "";
            fire -= 1;
            document.getElementById('Item4').src = "";
            value = 4;
            eval("blocktype" + number + "=" + value);
            id = "BlockImg" + number;
            document.getElementById(id).src = "Images/CampfireOn.png";
          }
        }
      }
    }else if(itemslot4 == 5){
      if(deleter == 1){
        itemslot4 = 0;
        document.getElementById("ItemName4").innerHTML = "";
        sickle -= 1;
        document.getElementById('Item4').src = "";
      }else if(deleter == 0){
        if(direction == 1){
          number = pos - 1;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
              console.log("Slot1");
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
              console.log("Slot2");
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
              console.log("Slot3");
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
              console.log("Slot4");
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }else if(direction == 2){
          number = pos - 10;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }else if(direction == 3){
          number = pos + 1;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }else if(direction == 4){
          number = pos + 10;
          if(eval("blocktype" + number) == 2){
            if(itemslot1 == 0){
                document.getElementById("Item1").src = "Images/LeafItem.png";
                itemslot1 = 6;
                document.getElementById("ItemName1").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot2 == 0){
                document.getElementById("Item2").src = "Images/LeafItem.png";
                itemslot2 = 6;
                document.getElementById("ItemName2").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot3 == 0){
                document.getElementById("Item3").src = "Images/LeafItem.png";
                itemslot3 = 6;
                document.getElementById("ItemName3").innerHTML = "Leaf";
                leaf += 1;
            }else if(itemslot4 == 0){
                document.getElementById("Item4").src = "Images/LeafItem.png";
                itemslot4 = 6;
                document.getElementById("ItemName4").innerHTML = "Leaf";
                leaf += 1;
            }
          }
        }
      }
    }else if(itemslot4 == 6){
      if(deleter == 1){
        itemslot4 = 0;
        document.getElementById("ItemName4").innerHTML = "";
        leaf -= 1;
        document.getElementById('Item4').src = "";
      }
    }else if(itemslot4 == 8){
      if(deleter == 1){
        itemslot4 = 0;
        document.getElementById("ItemName4").innerHTML = "";
        shovel -= 1;
        document.getElementById('Item4').src = "";
      }else if(deleter == 0){
        PathChecker();
      }
    }
  }
}

function Q(){
  if(deleter == 0){
    deleter = 1;
    document.getElementById("ItemSlot1").style.background = "red";
    document.getElementById("ItemSlot2").style.background = "red";
    document.getElementById("ItemSlot3").style.background = "red";
    document.getElementById("ItemSlot4").style.background = "red";
  }else if(deleter == 1){
    deleter = 0;
    document.getElementById("ItemSlot1").style.background = "#0000AA";
    document.getElementById("ItemSlot2").style.background = "#0000AA";
    document.getElementById("ItemSlot3").style.background = "#0000AA";
    document.getElementById("ItemSlot4").style.background = "#0000AA";
  }
}

function Crafting1(){
    if(craftscreen == 1){
      if(bamboo == 4){
          bamboo = 0;
          itemslot1 = 0;
          itemslot2 = 0;
          itemslot3 = 0;
          itemslot4 = 0;
          document.getElementById("ItemName1").innerHTML = "";
          document.getElementById('Item1').src = "";
          document.getElementById("ItemName2").innerHTML = "";
          document.getElementById('Item2').src = "";
          document.getElementById("ItemName3").innerHTML = "";
          document.getElementById('Item3').src = "";
          document.getElementById("ItemName4").innerHTML = "";
          document.getElementById('Item4').src = "";
          itemslot1 = 3;
          document.getElementById("ItemName1").innerHTML = "Campfire";
          document.getElementById('Item1').src = "Images/CampfireItem.png";
          campfire += 1;
        }
      }else if(craftscreen == 2){
        if((bamboo >= 1) && (rock >= 1)){
            if((itemslot2 == 2) && (itemslot1 == 1)){
              document.getElementById("ItemName2").innerHTML = "";
              document.getElementById("Item2").src = "";
              itemslot2 = 0;
              document.getElementById("ItemName1").innerHTML = "";
              document.getElementById("Item1").src = "";
              itemslot1 = 8;
              rock -= 1;
              bamboo -= 1;
              shovel += 1;
              document.getElementById("ItemName1").innerHTML = "Shovel";
              document.getElementById("Item1").src = "Images/ShovelItem.png";
            }else if((itemslot3 == 2) && (itemslot1 == 1)){
              document.getElementById("ItemName3").innerHTML = "";
              document.getElementById("Item3").src = "";
              itemslot3 = 0;
              document.getElementById("ItemName1").innerHTML = "";
              document.getElementById("Item1").src = "";
              itemslot1 = 8;
              rock -= 1;
              bamboo -= 1;
              shovel += 1;
              document.getElementById("ItemName1").innerHTML = "Shovel";
              document.getElementById("Item1").src = "Images/ShovelItem.png";
            }else if((itemslot4 == 2) && (itemslot1 == 1)){
              document.getElementById("ItemName4").innerHTML = "";
              document.getElementById("Item4").src = "";
              itemslot4 = 0;
              document.getElementById("ItemName1").innerHTML = "";
              document.getElementById("Item1").src = "";
              itemslot1 = 8;
              rock -= 2;
              shovel += 1;
              document.getElementById("ItemName1").innerHTML = "Shovel";
              document.getElementById("Item1").src = "Images/ShovelItem.png";
            }else if((itemslot3 == 2) && (itemslot2 == 1)){
              document.getElementById("ItemName3").innerHTML = "";
              document.getElementById("Item3").src = "";
              itemslot3 = 0;
              document.getElementById("ItemName2").innerHTML = "";
              document.getElementById("Item2").src = "";
              itemslot2 = 8;
              rock -= 1;
              bamboo -= 1;
              shovel += 1;
              document.getElementById("ItemName2").innerHTML = "Shovel";
              document.getElementById("Item2").src = "Images/ShovelItem.png";
            }else if((itemslot4 == 2) && (itemslot2 == 1)){
              document.getElementById("ItemName4").innerHTML = "";
              document.getElementById("Item4").src = "";
              itemslot4 = 0;
              document.getElementById("ItemName2").innerHTML = "";
              document.getElementById("Item2").src = "";
              itemslot2 = 8;
              rock -= 1;
              bamboo -= 1;
              shovel += 1;
              document.getElementById("ItemName2").innerHTML = "Shovel";
              document.getElementById("Item2").src = "Images/ShovelItem.png";
            }else if((itemslot4 == 2) && (itemslot3 == 1)){
              document.getElementById("ItemName4").innerHTML = "";
              document.getElementById("Item4").src = "";
              itemslot4 = 0;
              document.getElementById("ItemName3").innerHTML = "";
              document.getElementById("Item3").src = "";
              itemslot3 = 8;
              rock -= 1;
              bamboo -= 1;
              shovel += 1;
              document.getElementById("ItemName3").innerHTML = "Shovel";
              document.getElementById("Item3").src = "Images/ShovelItem.png";
            }else if((itemslot2 == 1) && (itemslot1 == 2)){
              document.getElementById("ItemName2").innerHTML = "";
              document.getElementById("Item2").src = "";
              itemslot2 = 0;
              document.getElementById("ItemName1").innerHTML = "";
              document.getElementById("Item1").src = "";
              itemslot1 = 8;
              rock -= 1;
              bamboo -= 1;
              shovel += 1;
              document.getElementById("ItemName1").innerHTML = "Shovel";
              document.getElementById("Item1").src = "Images/ShovelItem.png";
            }else if((itemslot3 == 1) && (itemslot1 == 2)){
              document.getElementById("ItemName3").innerHTML = "";
              document.getElementById("Item3").src = "";
              itemslot3 = 0;
              document.getElementById("ItemName1").innerHTML = "";
              document.getElementById("Item1").src = "";
              itemslot1 = 8;
              rock -= 1;
              bamboo -= 1;
              shovel += 1;
              document.getElementById("ItemName1").innerHTML = "Shovel";
              document.getElementById("Item1").src = "Images/ShovelItem.png";
            }else if((itemslot4 == 1) && (itemslot1 == 2)){
              document.getElementById("ItemName4").innerHTML = "";
              document.getElementById("Item4").src = "";
              itemslot4 = 0;
              document.getElementById("ItemName1").innerHTML = "";
              document.getElementById("Item1").src = "";
              itemslot1 = 8;
              rock -= 2;
              shovel += 1;
              document.getElementById("ItemName1").innerHTML = "Shovel";
              document.getElementById("Item1").src = "Images/ShovelItem.png";
            }else if((itemslot3 == 1) && (itemslot2 == 2)){
              document.getElementById("ItemName3").innerHTML = "";
              document.getElementById("Item3").src = "";
              itemslot3 = 0;
              document.getElementById("ItemName2").innerHTML = "";
              document.getElementById("Item2").src = "";
              itemslot2 = 8;
              rock -= 1;
              bamboo -= 1;
              shovel += 1;
              document.getElementById("ItemName2").innerHTML = "Shovel";
              document.getElementById("Item2").src = "Images/ShovelItem.png";
            }else if((itemslot4 == 1) && (itemslot2 == 2)){
              document.getElementById("ItemName4").innerHTML = "";
              document.getElementById("Item4").src = "";
              itemslot4 = 0;
              document.getElementById("ItemName2").innerHTML = "";
              document.getElementById("Item2").src = "";
              itemslot2 = 8;
              rock -= 1;
              bamboo -= 1;
              shovel += 1;
              document.getElementById("ItemName2").innerHTML = "Shovel";
              document.getElementById("Item2").src = "Images/ShovelItem.png";
            }else if((itemslot4 == 1) && (itemslot3 == 2)){
              document.getElementById("ItemName4").innerHTML = "";
              document.getElementById("Item4").src = "";
              itemslot4 = 0;
              document.getElementById("ItemName3").innerHTML = "";
              document.getElementById("Item3").src = "";
              itemslot3 = 8;
              rock -= 1;
              bamboo -= 1;
              shovel += 1;
              document.getElementById("ItemName3").innerHTML = "Shovel";
              document.getElementById("Item3").src = "Images/ShovelItem.png";
            }
        }
      }
    }

function Crafting2(){
  if(craftscreen == 1){
    if(rock >= 2){
      if(itemslot1 == 1){
        if(itemslot2 == 1){
          document.getElementById("ItemName2").innerHTML = "";
          document.getElementById("Item2").src = "";
          itemslot2 = 0;
          document.getElementById("ItemName1").innerHTML = "";
          document.getElementById("Item1").src = "";
          itemslot1 = 4;
          rock -= 2;
          fire += 1;
          document.getElementById("ItemName1").innerHTML = "Fire";
          document.getElementById("Item1").src = "Images/FireItem.png";
        }else if(itemslot3 == 1){
          document.getElementById("ItemName3").innerHTML = "";
          document.getElementById("Item3").src = "";
          itemslot3 = 0;
          document.getElementById("ItemName1").innerHTML = "";
          document.getElementById("Item1").src = "";
          itemslot1 = 4;
          rock -= 2;
          fire += 1;
          document.getElementById("ItemName1").innerHTML = "Fire";
          document.getElementById("Item1").src = "Images/FireItem.png";
        }else if(itemslot4 == 1){
          document.getElementById("ItemName4").innerHTML = "";
          document.getElementById("Item4").src = "";
          itemslot4 = 0;
          document.getElementById("ItemName1").innerHTML = "";
          document.getElementById("Item1").src = "";
          itemslot1 = 4;
          rock -= 2;
          fire += 1;
          document.getElementById("ItemName1").innerHTML = "Fire";
          document.getElementById("Item1").src = "Images/FireItem.png";
        }
      }else if(itemslot2 == 1){
        if(itemslot3 == 1){
          document.getElementById("ItemName3").innerHTML = "";
          document.getElementById("Item3").src = "";
          itemslot3 = 0;
          document.getElementById("ItemName2").innerHTML = "";
          document.getElementById("Item2").src = "";
          itemslot2 = 4;
          rock -= 2;
          fire += 1;
          document.getElementById("ItemName2").innerHTML = "Fire";
          document.getElementById("Item2").src = "Images/FireItem.png";
        }else if(itemslot4 == 1){
          document.getElementById("ItemName4").innerHTML = "";
          document.getElementById("Item4").src = "";
          itemslot4 = 0;
          document.getElementById("ItemName2").innerHTML = "";
          document.getElementById("Item2").src = "";
          itemslot2 = 4;
          rock -= 2;
          fire += 1;
          document.getElementById("ItemName2").innerHTML = "Fire";
          document.getElementById("Item2").src = "Images/FireItem.png";
        }
      }else if(itemslot3 == 1){
        if(itemslot4 == 1){
          document.getElementById("ItemName4").innerHTML = "";
          document.getElementById("Item4").src = "";
          itemslot4 = 0;
          document.getElementById("ItemName3").innerHTML = "";
          document.getElementById("Item3").src = "";
          itemslot3 = 4;
          rock -= 2;
          fire += 1;
          document.getElementById("ItemName3").innerHTML = "Fire";
          document.getElementById("Item3").src = "Images/FireItem.png";
        }
      }
    }
  }else if(craftscreen == 2){
    if(bamboo == 4){
      bamboo = 0;
      itemslot1 = 0;
      itemslot2 = 0;
      itemslot3 = 0;
      itemslot4 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      document.getElementById('Item1').src = "";
      document.getElementById("ItemName2").innerHTML = "";
      document.getElementById('Item2').src = "";
      document.getElementById("ItemName3").innerHTML = "";
      document.getElementById('Item3').src = "";
      document.getElementById("ItemName4").innerHTML = "";
      document.getElementById('Item4').src = "";
      itemslot1 = 9;
      document.getElementById("ItemName1").innerHTML = "House Wall";
      document.getElementById('Item1').src = "Images/BambooWallItem.png";
      wall += 1;
    }
  }
}

function Crafting3(){
  if(craftscreen == 1){
    if((bamboo >= 1) && (rock >= 1)){
      if((itemslot2 == 2) && (itemslot1 == 1)){
        document.getElementById("ItemName2").innerHTML = "";
        document.getElementById("Item2").src = "";
        itemslot2 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        document.getElementById("Item1").src = "";
        itemslot1 = 5;
        rock -= 1;
        bamboo -= 1;
        sickle += 1;
        document.getElementById("ItemName1").innerHTML = "Sickle";
        document.getElementById("Item1").src = "Images/SickleItem.png";
      }else if((itemslot3 == 2) && (itemslot1 == 1)){
        document.getElementById("ItemName3").innerHTML = "";
        document.getElementById("Item3").src = "";
        itemslot3 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        document.getElementById("Item1").src = "";
        itemslot1 = 5;
        rock -= 1;
        bamboo -= 1;
        sickle += 1;
        document.getElementById("ItemName1").innerHTML = "Sickle";
        document.getElementById("Item1").src = "Images/SickleItem.png";
      }else if((itemslot4 == 2) && (itemslot1 == 1)){
        document.getElementById("ItemName4").innerHTML = "";
        document.getElementById("Item4").src = "";
        itemslot4 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        document.getElementById("Item1").src = "";
        itemslot1 = 5;
        rock -= 2;
        sickle += 1;
        document.getElementById("ItemName1").innerHTML = "Sickle";
        document.getElementById("Item1").src = "Images/SickleItem.png";
      }else if((itemslot3 == 2) && (itemslot2 == 1)){
        document.getElementById("ItemName3").innerHTML = "";
        document.getElementById("Item3").src = "";
        itemslot3 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        document.getElementById("Item2").src = "";
        itemslot2 = 5;
        rock -= 1;
        bamboo -= 1;
        sickle += 1;
        document.getElementById("ItemName2").innerHTML = "Sickle";
        document.getElementById("Item2").src = "Images/SickleItem.png";
      }else if((itemslot4 == 2) && (itemslot2 == 1)){
        document.getElementById("ItemName4").innerHTML = "";
        document.getElementById("Item4").src = "";
        itemslot4 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        document.getElementById("Item2").src = "";
        itemslot2 = 5;
        rock -= 1;
        bamboo -= 1;
        sickle += 1;
        document.getElementById("ItemName2").innerHTML = "Sickle";
        document.getElementById("Item2").src = "Images/SickleItem.png";
      }else if((itemslot4 == 2) && (itemslot3 == 1)){
        document.getElementById("ItemName4").innerHTML = "";
        document.getElementById("Item4").src = "";
        itemslot4 = 0;
        document.getElementById("ItemName3").innerHTML = "";
        document.getElementById("Item3").src = "";
        itemslot3 = 5;
        rock -= 1;
        bamboo -= 1;
        sickle += 1;
        document.getElementById("ItemName3").innerHTML = "Sickle";
        document.getElementById("Item3").src = "Images/SickleItem.png";
      }else if((itemslot2 == 1) && (itemslot1 == 2)){
        document.getElementById("ItemName2").innerHTML = "";
        document.getElementById("Item2").src = "";
        itemslot2 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        document.getElementById("Item1").src = "";
        itemslot1 = 5;
        rock -= 1;
        bamboo -= 1;
        sickle += 1;
        document.getElementById("ItemName1").innerHTML = "Sickle";
        document.getElementById("Item1").src = "Images/SickleItem.png";
      }else if((itemslot3 == 1) && (itemslot1 == 2)){
        document.getElementById("ItemName3").innerHTML = "";
        document.getElementById("Item3").src = "";
        itemslot3 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        document.getElementById("Item1").src = "";
        itemslot1 = 5;
        rock -= 1;
        bamboo -= 1;
        sickle += 1;
        document.getElementById("ItemName1").innerHTML = "Sickle";
        document.getElementById("Item1").src = "Images/SickleItem.png";
      }else if((itemslot4 == 1) && (itemslot1 == 2)){
        document.getElementById("ItemName4").innerHTML = "";
        document.getElementById("Item4").src = "";
        itemslot4 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        document.getElementById("Item1").src = "";
        itemslot1 = 5;
        rock -= 2;
        sickle += 1;
        document.getElementById("ItemName1").innerHTML = "Sickle";
        document.getElementById("Item1").src = "Images/SickleItem.png";
      }else if((itemslot3 == 1) && (itemslot2 == 2)){
        document.getElementById("ItemName3").innerHTML = "";
        document.getElementById("Item3").src = "";
        itemslot3 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        document.getElementById("Item2").src = "";
        itemslot2 = 5;
        rock -= 1;
        bamboo -= 1;
        sickle += 1;
        document.getElementById("ItemName2").innerHTML = "Sickle";
        document.getElementById("Item2").src = "Images/SickleItem.png";
      }else if((itemslot4 == 1) && (itemslot2 == 2)){
        document.getElementById("ItemName4").innerHTML = "";
        document.getElementById("Item4").src = "";
        itemslot4 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        document.getElementById("Item2").src = "";
        itemslot2 = 5;
        rock -= 1;
        bamboo -= 1;
        sickle += 1;
        document.getElementById("ItemName2").innerHTML = "Sickle";
        document.getElementById("Item2").src = "Images/SickleItem.png";
      }else if((itemslot4 == 1) && (itemslot3 == 2)){
        document.getElementById("ItemName4").innerHTML = "";
        document.getElementById("Item4").src = "";
        itemslot4 = 0;
        document.getElementById("ItemName3").innerHTML = "";
        document.getElementById("Item3").src = "";
        itemslot3 = 5;
        rock -= 1;
        bamboo -= 1;
        sickle += 1;
        document.getElementById("ItemName3").innerHTML = "Sickle";
        document.getElementById("Item3").src = "Images/SickleItem.png";
      }
    }
  }else if(craftscreen == 2){
    if((bamboo >= 1) && (leaf >= 1)){
      if((itemslot2 == 2) && (itemslot1 == 6)){
        document.getElementById("ItemName2").innerHTML = "";
        document.getElementById("Item2").src = "";
        itemslot2 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        document.getElementById("Item1").src = "";
        itemslot1 = 10;
        leaf -= 1;
        bamboo -= 1;
        leafstick += 1;
        document.getElementById("ItemName1").innerHTML = "Leafsticks";
        document.getElementById("Item1").src = "Images/LeafStickItem.png";
      }else if((itemslot3 == 2) && (itemslot1 == 6)){
        document.getElementById("ItemName3").innerHTML = "";
        document.getElementById("Item3").src = "";
        itemslot3 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        document.getElementById("Item1").src = "";
        itemslot1 = 10;
        leaf -= 1;
        bamboo -= 1;
        leafstick += 1;
        document.getElementById("ItemName1").innerHTML = "Leafsticks";
        document.getElementById("Item1").src = "Images/LeafStickItem.png";
      }else if((itemslot4 == 2) && (itemslot1 == 6)){
        document.getElementById("ItemName4").innerHTML = "";
        document.getElementById("Item4").src = "";
        itemslot4 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        document.getElementById("Item1").src = "";
        itemslot1 = 10;
        leaf -= 1;
        leafstick += 1;
        document.getElementById("ItemName1").innerHTML = "Leafsticks";
        document.getElementById("Item1").src = "Images/LeafStickItem.png";
      }else if((itemslot3 == 2) && (itemslot2 == 6)){
        document.getElementById("ItemName3").innerHTML = "";
        document.getElementById("Item3").src = "";
        itemslot3 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        document.getElementById("Item2").src = "";
        itemslot2 = 10;
        leaf -= 1;
        bamboo -= 1;
        leafstick += 1;
        document.getElementById("ItemName2").innerHTML = "Leafsticks";
        document.getElementById("Item2").src = "Images/LeafStickItem.png";
      }else if((itemslot4 == 2) && (itemslot2 == 6)){
        document.getElementById("ItemName4").innerHTML = "";
        document.getElementById("Item4").src = "";
        itemslot4 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        document.getElementById("Item2").src = "";
        itemslot2 = 10;
        leaf -= 1;
        bamboo -= 1;
        leafstick += 1;
        document.getElementById("ItemName2").innerHTML = "Leafsticks";
        document.getElementById("Item2").src = "Images/LeafStickItem.png";
      }else if((itemslot4 == 2) && (itemslot3 == 6)){
        document.getElementById("ItemName4").innerHTML = "";
        document.getElementById("Item4").src = "";
        itemslot4 = 0;
        document.getElementById("ItemName3").innerHTML = "";
        document.getElementById("Item3").src = "";
        itemslot3 = 10;
        leaf -= 1;
        bamboo -= 1;
        leafstick += 1;
        document.getElementById("ItemName3").innerHTML = "Leafsticks";
        document.getElementById("Item3").src = "Images/LeafStickItem.png";
      }else if((itemslot2 == 6) && (itemslot1 == 2)){
        document.getElementById("ItemName2").innerHTML = "";
        document.getElementById("Item2").src = "";
        itemslot2 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        document.getElementById("Item1").src = "";
        itemslot1 = 10;
        leaf -= 1;
        bamboo -= 1;
        leafstick += 1;
        document.getElementById("ItemName1").innerHTML = "Leafsticks";
        document.getElementById("Item1").src = "Images/LeafStickItem.png";
      }else if((itemslot3 == 6) && (itemslot1 == 2)){
        document.getElementById("ItemName3").innerHTML = "";
        document.getElementById("Item3").src = "";
        itemslot3 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        document.getElementById("Item1").src = "";
        itemslot1 = 10;
        leaf -= 1;
        bamboo -= 1;
        leafstick += 1;
        document.getElementById("ItemName1").innerHTML = "Leafsticks";
        document.getElementById("Item1").src = "Images/LeafStickItem.png";
      }else if((itemslot4 == 6) && (itemslot1 == 2)){
        document.getElementById("ItemName4").innerHTML = "";
        document.getElementById("Item4").src = "";
        itemslot4 = 0;
        document.getElementById("ItemName1").innerHTML = "";
        document.getElementById("Item1").src = "";
        itemslot1 = 10;
        leaf -= 1;
        bamboo -= 1;
        leafstick += 1;
        document.getElementById("ItemName1").innerHTML = "Leafsticks";
        document.getElementById("Item1").src = "Images/LeafStickItem.png";
      }else if((itemslot3 == 6) && (itemslot2 == 2)){
        document.getElementById("ItemName3").innerHTML = "";
        document.getElementById("Item3").src = "";
        itemslot3 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        document.getElementById("Item2").src = "";
        itemslot2 = 10;
        leaf -= 1;
        bamboo -= 1;
        leafstick += 1;
        document.getElementById("ItemName2").innerHTML = "Leafsticks";
        document.getElementById("Item2").src = "Images/LeafStickItem.png";
      }else if((itemslot4 == 6) && (itemslot2 == 2)){
        document.getElementById("ItemName4").innerHTML = "";
        document.getElementById("Item4").src = "";
        itemslot4 = 0;
        document.getElementById("ItemName2").innerHTML = "";
        document.getElementById("Item2").src = "";
        itemslot2 = 10;
        leaf -= 1;
        bamboo -= 1;
        leafstick += 1;
        document.getElementById("ItemName2").innerHTML = "Leafsticks";
        document.getElementById("Item2").src = "Images/LeafStickItem.png";
      }else if((itemslot4 == 6) && (itemslot3 == 2)){
        document.getElementById("ItemName4").innerHTML = "";
        document.getElementById("Item4").src = "";
        itemslot4 = 0;
        document.getElementById("ItemName3").innerHTML = "";
        document.getElementById("Item3").src = "";
        itemslot3 = 10;
        leaf -= 1;
        bamboo -= 1;
        leafstick += 1;
        document.getElementById("ItemName3").innerHTML = "Leafsticks";
        document.getElementById("Item3").src = "Images/LeafStickItem.png";
      }
    }
  }
}

function Crafting4(){
  if(craftscreen == 1){
    if((bamboo >= 1) && (leaf >= 3)){
      if(itemslot1 == 2){
        if((itemslot2 == 6) && (itemslot3 == 6) && (itemslot4 == 6)){
          console.log("Tent");
          document.getElementById("ItemName1").innerHTML = "";
          document.getElementById("Item1").src = "";
          itemslot1 = 0
          document.getElementById("ItemName2").innerHTML = "";
          document.getElementById("Item2").src = "";
          itemslot2 = 0;
          document.getElementById("ItemName3").innerHTML = "";
          document.getElementById("Item3").src = "";
          itemslot3 = 0;
          document.getElementById("ItemName4").innerHTML = "";
          document.getElementById("Item4").src = "";
          itemslot4 = 0;
          itemslot1 = 7;
          leaf -= 3;
          bamboo -= 1;
          tent += 1;
          document.getElementById("ItemName1").innerHTML = "Tent";
          document.getElementById("Item1").src = "Images/TentItem.png";
        }
      }else if(itemslot2 == 2){
        if((itemslot1 == 6) && (itemslot3 == 6) && (itemslot4 == 6)){
          document.getElementById("ItemName1").innerHTML = "";
          document.getElementById("Item1").src = "";
          itemslot1 = 0
          document.getElementById("ItemName2").innerHTML = "";
          document.getElementById("Item2").src = "";
          itemslot2 = 0;
          document.getElementById("ItemName3").innerHTML = "";
          document.getElementById("Item3").src = "";
          itemslot3 = 0;
          document.getElementById("ItemName4").innerHTML = "";
          document.getElementById("Item4").src = "";
          itemslot4 = 0;
          itemslot1 = 7;
          leaf -= 3;
          bamboo -= 1;
          tent += 1;
          document.getElementById("ItemName1").innerHTML = "Tent";
          document.getElementById("Item1").src = "Images/TentItem.png";
        }
      }else if(itemslot3 == 2){
        if((itemslot2 == 6) && (itemslot1 == 6) && (itemslot4 == 6)){
          document.getElementById("ItemName1").innerHTML = "";
          document.getElementById("Item1").src = "";
          itemslot1 = 0
          document.getElementById("ItemName2").innerHTML = "";
          document.getElementById("Item2").src = "";
          itemslot2 = 0;
          document.getElementById("ItemName3").innerHTML = "";
          document.getElementById("Item3").src = "";
          itemslot3 = 0;
          document.getElementById("ItemName4").innerHTML = "";
          document.getElementById("Item4").src = "";
          itemslot4 = 0;
          itemslot1 = 7;
          leaf -= 3;
          bamboo -= 1;
          tent += 1;
          document.getElementById("ItemName1").innerHTML = "Tent";
          document.getElementById("Item1").src = "Images/TentItem.png";
        }
      }else if(itemslot4 == 2){
        if((itemslot2 == 6) && (itemslot3 == 6) && (itemslot1 == 6)){
          document.getElementById("ItemName1").innerHTML = "";
          document.getElementById("Item1").src = "";
          itemslot1 = 0
          document.getElementById("ItemName2").innerHTML = "";
          document.getElementById("Item2").src = "";
          itemslot2 = 0;
          document.getElementById("ItemName3").innerHTML = "";
          document.getElementById("Item3").src = "";
          itemslot3 = 0;
          document.getElementById("ItemName4").innerHTML = "";
          document.getElementById("Item4").src = "";
          itemslot4 = 0;
          itemslot1 = 7;
          leaf -= 3;
          bamboo -= 1;
          tent += 1;
          document.getElementById("ItemName1").innerHTML = "Tent";
          document.getElementById("Item1").src = "Images/TentItem.png";
        }
      }
    }
  }else if(craftscreen == 2){
    if((bamboo >= 1) && (leafstick >= 3)){
      console.log("Amount");
      if(itemslot1 == 2){
        if((itemslot2 == 10) && (itemslot3 == 10) && (itemslot4 == 10)){
          document.getElementById("ItemName1").innerHTML = "";
          document.getElementById("Item1").src = "";
          itemslot1 = 0
          document.getElementById("ItemName2").innerHTML = "";
          document.getElementById("Item2").src = "";
          itemslot2 = 0;
          document.getElementById("ItemName3").innerHTML = "";
          document.getElementById("Item3").src = "";
          itemslot3 = 0;
          document.getElementById("ItemName4").innerHTML = "";
          document.getElementById("Item4").src = "";
          itemslot4 = 0;
          itemslot1 = 11;
          leafstick -= 3;
          bamboo -= 1;
          roof += 1;
          document.getElementById("ItemName1").innerHTML = "Roof";
          document.getElementById("Item1").src = "Images/RoofItem.png";
        }
      }else if(itemslot2 == 2){
        if((itemslot1 == 10) && (itemslot3 == 10) && (itemslot4 == 10)){
          document.getElementById("ItemName1").innerHTML = "";
          document.getElementById("Item1").src = "";
          itemslot1 = 0
          document.getElementById("ItemName2").innerHTML = "";
          document.getElementById("Item2").src = "";
          itemslot2 = 0;
          document.getElementById("ItemName3").innerHTML = "";
          document.getElementById("Item3").src = "";
          itemslot3 = 0;
          document.getElementById("ItemName4").innerHTML = "";
          document.getElementById("Item4").src = "";
          itemslot4 = 0;
          itemslot1 = 11;
          leafstick -= 3;
          bamboo -= 1;
          roof += 1;
          document.getElementById("ItemName1").innerHTML = "Roof";
          document.getElementById("Item1").src = "Images/RoofItem.png";
        }
      }else if(itemslot3 == 2){
        if((itemslot2 == 10) && (itemslot1 == 10) && (itemslot4 == 10)){
          document.getElementById("ItemName1").innerHTML = "";
          document.getElementById("Item1").src = "";
          itemslot1 = 0
          document.getElementById("ItemName2").innerHTML = "";
          document.getElementById("Item2").src = "";
          itemslot2 = 0;
          document.getElementById("ItemName3").innerHTML = "";
          document.getElementById("Item3").src = "";
          itemslot3 = 0;
          document.getElementById("ItemName4").innerHTML = "";
          document.getElementById("Item4").src = "";
          itemslot4 = 0;
          itemslot1 = 11;
          leafstick -= 3;
          bamboo -= 1;
          roof += 1;
          document.getElementById("ItemName1").innerHTML = "Roof";
          document.getElementById("Item1").src = "Images/RoofItem.png";
        }
      }else if(itemslot4 == 2){
        if((itemslot2 == 10) && (itemslot3 == 10) && (itemslot1 == 10)){
          document.getElementById("ItemName1").innerHTML = "";
          document.getElementById("Item1").src = "";
          itemslot1 = 0
          document.getElementById("ItemName2").innerHTML = "";
          document.getElementById("Item2").src = "";
          itemslot2 = 0;
          document.getElementById("ItemName3").innerHTML = "";
          document.getElementById("Item3").src = "";
          itemslot3 = 0;
          document.getElementById("ItemName4").innerHTML = "";
          document.getElementById("Item4").src = "";
          itemslot4 = 0;
          itemslot1 = 11;
          leafstick -= 3;
          bamboo -= 1;
          roof += 1;
          document.getElementById("ItemName1").innerHTML = "Roof";
          document.getElementById("Item1").src = "Images/RoofItem.png";
        }
      }
    }
  }
}

function TurnLeft(){
  if(eval("blocktype" + pos) == 0){
    if(direction != 1){
      direction = 1;
      id = "BlockImg" + pos;
      document.getElementById(id).src = "Images/PlayerLeft.png";
    }
  }else if(eval("blocktype" + pos) == 8){
    if(direction != 1){
      direction = 1;
      id = "BlockImg" + pos;
      source = document.getElementById(id).src;
      source = source.substring(0, source.length - 6);
      document.getElementById(id).src = source + "PL.png";
    }
  }else if((eval("blocktype" + pos) == 208) || (eval("blocktype" + pos) == 209) || (eval("blocktype" + pos) == 210)){
    if(direction != 1){
      direction = 1;
      id = "BlockImg" + pos;
      document.getElementById(id).src = "Images/HouseWithPSide.png";
      value = 207;
      eval("blocktype" + pos + "=" + value);
    }
  }
}

function TurnUp(){
  if(eval("blocktype" + pos) == 0){
    if(direction != 2){
      direction = 2;
      id = "BlockImg" + pos;
      document.getElementById(id).src = "Images/PlayerBack.png";
    }
  }else if(eval("blocktype" + pos) == 8){
    if(direction != 2){
      direction = 2;
      id = "BlockImg" + pos;
      source = document.getElementById(id).src;
      source = source.substring(0, source.length - 6);
      document.getElementById(id).src = source + "PB.png";
    }
  }else if((eval("blocktype" + pos) == 207) || (eval("blocktype" + pos) == 209) || (eval("blocktype" + pos) == 210)){
    if(direction != 2){
      direction = 2;
      id = "BlockImg" + pos;
      document.getElementById(id).src = "Images/HouseWithPFront.png";
      value = 208;
      eval("blocktype" + pos + "=" + value);
    }
  }
}

function TurnRight(){
  if(eval("blocktype" + pos) == 0){
    if(direction != 3){
      direction = 3;
      id = "BlockImg" + pos;
      document.getElementById(id).src = "Images/PlayerRight.png";
    }
  }else if(eval("blocktype" + pos) == 8){
    if(direction != 3){
      direction = 3;
      id = "BlockImg" + pos;
      source = document.getElementById(id).src;
      source = source.substring(0, source.length - 6);
      document.getElementById(id).src = source + "PR.png";
    }
  }else if((eval("blocktype" + pos) == 207) || (eval("blocktype" + pos) == 208) || (eval("blocktype" + pos) == 210)){
    if(direction != 3){
      direction = 3;
      id = "BlockImg" + pos;
      document.getElementById(id).src = "Images/HouseWithPSide.png";
      value = 209;
      eval("blocktype" + pos + "=" + value);
    }
  }
}

function TurnDown(){
  if(eval("blocktype" + pos) == 0){
    if(direction != 4){
      direction = 4;
      id = "BlockImg" + pos;
      document.getElementById(id).src = "Images/PlayerFront.png";
    }
  }else if(eval("blocktype" + pos) == 8){
    if(direction != 4){
      direction = 4;
      id = "BlockImg" + pos;
      source = document.getElementById(id).src;
      source = source.substring(0, source.length - 6);
      document.getElementById(id).src = source + "PF.png";
    }
  }else if((eval("blocktype" + pos) == 207) || (eval("blocktype" + pos) == 208) || (eval("blocktype" + pos) == 209)){
    if(direction != 4){
      direction = 4;
      id = "BlockImg" + pos;
      document.getElementById(id).src = "Images/HouseWithPFront.png";
      value = 210;
      eval("blocktype" + pos + "=" + value);
    }
  }
}

function CraftLeft(){
  if(craftscreen == 1){
    craftscreen = 2;
    document.getElementById("CraftingScreen").src = "Images/ItemCraft2.png";
  }else if(craftscreen == 2){
    craftscreen = 1;
    document.getElementById("CraftingScreen").src = "Images/ItemCraft1.png";
  }
}

function CraftRight(){
  if(craftscreen == 1){
    craftscreen = 2;
    document.getElementById("CraftingScreen").src = "Images/ItemCraft2.png";
  }else if(craftscreen == 2){
    craftscreen = 1;
    document.getElementById("CraftingScreen").src = "Images/ItemCraft1.png";
  }
}

function PathChecker(){
  if(direction == 1){
    if((pos != 1) && (pos != 11) && (pos != 21) && (pos != 31) && (pos != 41) && (pos != 51) && (pos != 61)){
      number = pos - 1;
      if((eval("blocktype" + number) == 0) || (eval("blocktype" + number) == 8)){
        value = 8;
        if((eval("path" + number) == 0) || (eval("path" + number) == 12)){
          eval("path" + number + "=" + "1");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathHorizontal.png"
        }else if(eval("path" + number) == 1){
          eval("path" + number + "=" + "2");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathVertical.png"
        }else if(eval("path" + number) == 2){
          eval("path" + number + "=" + "3");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathUL.png"
        }else if(eval("path" + number) == 3){
          eval("path" + number + "=" + "4");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathUR.png"
        }else if(eval("path" + number) == 4){
          eval("path" + number + "=" + "5");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathDR.png"
        }else if(eval("path" + number) == 5){
          eval("path" + number + "=" + "6");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathDL.png"
        }else if(eval("path" + number) == 6){
          eval("path" + number + "=" + "7");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathCross.png"
        }else if(eval("path" + number) == 7){
          eval("path" + number + "=" + "8");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTL.png"
        }else if(eval("path" + number) == 8){
          eval("path" + number + "=" + "9");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTU.png"
        }else if(eval("path" + number) == 9){
          eval("path" + number + "=" + "10");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTR.png"
        }else if(eval("path" + number) == 10){
          eval("path" + number + "=" + "11");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTD.png"
        }else if(eval("path" + number) == 11){
          eval("path" + number + "=" + "12");
          value = 0;
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Images/Grass.png"
        }
      }
    }
  }else if(direction == 2){
    if((pos != 1) && (pos != 2) && (pos != 3) && (pos != 4) && (pos != 5) && (pos != 6) && (pos != 7) && (pos != 8) && (pos != 9) && (pos != 10)){
      number = pos - 10;
      if((eval("blocktype" + number) == 0) || (eval("blocktype" + number) == 8)){
        value = 8;
        if((eval("path" + number) == 0) || (eval("path" + number) == 12)){
          eval("path" + number + "=" + "1");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathHorizontal.png"
        }else if(eval("path" + number) == 1){
          eval("path" + number + "=" + "2");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathVertical.png"
        }else if(eval("path" + number) == 2){
          eval("path" + number + "=" + "3");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathUL.png"
        }else if(eval("path" + number) == 3){
          eval("path" + number + "=" + "4");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathUR.png"
        }else if(eval("path" + number) == 4){
          eval("path" + number + "=" + "5");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathDR.png"
        }else if(eval("path" + number) == 5){
          eval("path" + number + "=" + "6");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathDL.png"
        }else if(eval("path" + number) == 6){
          eval("path" + number + "=" + "7");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathCross.png"
        }else if(eval("path" + number) == 7){
          eval("path" + number + "=" + "8");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTL.png"
        }else if(eval("path" + number) == 8){
          eval("path" + number + "=" + "9");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTU.png"
        }else if(eval("path" + number) == 9){
          eval("path" + number + "=" + "10");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTR.png"
        }else if(eval("path" + number) == 10){
          eval("path" + number + "=" + "11");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTD.png"
        }else if(eval("path" + number) == 11){
          eval("path" + number + "=" + "12");
          value = 0;
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Images/Grass.png"
        }
      }
    }
  }else if(direction == 3){
    if((pos != 10) && (pos != 20) && (pos != 30) && (pos != 40) && (pos != 50) && (pos != 60) && (pos != 70)){
      number = pos + 1;
      if((eval("blocktype" + number) == 0) || (eval("blocktype" + number) == 8)){
        value = 8;
        if((eval("path" + number) == 0) || (eval("path" + number) == 12)){
          eval("path" + number + "=" + "1");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathHorizontal.png"
        }else if(eval("path" + number) == 1){
          eval("path" + number + "=" + "2");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathVertical.png"
        }else if(eval("path" + number) == 2){
          eval("path" + number + "=" + "3");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathUL.png"
        }else if(eval("path" + number) == 3){
          eval("path" + number + "=" + "4");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathUR.png"
        }else if(eval("path" + number) == 4){
          eval("path" + number + "=" + "5");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathDR.png"
        }else if(eval("path" + number) == 5){
          eval("path" + number + "=" + "6");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathDL.png"
        }else if(eval("path" + number) == 6){
          eval("path" + number + "=" + "7");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathCross.png"
        }else if(eval("path" + number) == 7){
          eval("path" + number + "=" + "8");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTL.png"
        }else if(eval("path" + number) == 8){
          eval("path" + number + "=" + "9");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTU.png"
        }else if(eval("path" + number) == 9){
          eval("path" + number + "=" + "10");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTR.png"
        }else if(eval("path" + number) == 10){
          eval("path" + number + "=" + "11");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTD.png"
        }else if(eval("path" + number) == 11){
          eval("path" + number + "=" + "12");
          value = 0;
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Images/Grass.png"
        }
      }
    }
  }else if(direction == 4){
    if((pos != 61) && (pos != 62) && (pos != 63) && (pos != 64) && (pos != 65) && (pos != 66) && (pos != 67) && (pos != 68) && (pos != 69) && (pos != 70)){
      number = pos + 10;
      if((eval("blocktype" + number) == 0) || (eval("blocktype" + number) == 8)){
        value = 8;
        if((eval("path" + number) == 0) || (eval("path" + number) == 12)){
          eval("path" + number + "=" + "1");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathHorizontal.png"
        }else if(eval("path" + number) == 1){
          eval("path" + number + "=" + "2");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathVertical.png"
        }else if(eval("path" + number) == 2){
          eval("path" + number + "=" + "3");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathUL.png"
        }else if(eval("path" + number) == 3){
          eval("path" + number + "=" + "4");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathUR.png"
        }else if(eval("path" + number) == 4){
          eval("path" + number + "=" + "5");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathDR.png"
        }else if(eval("path" + number) == 5){
          eval("path" + number + "=" + "6");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathDL.png"
        }else if(eval("path" + number) == 6){
          eval("path" + number + "=" + "7");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathCross.png"
        }else if(eval("path" + number) == 7){
          eval("path" + number + "=" + "8");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTL.png"
        }else if(eval("path" + number) == 8){
          eval("path" + number + "=" + "9");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTU.png"
        }else if(eval("path" + number) == 9){
          eval("path" + number + "=" + "10");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTR.png"
        }else if(eval("path" + number) == 10){
          eval("path" + number + "=" + "11");
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Path/PathTD.png"
        }else if(eval("path" + number) == 11){
          eval("path" + number + "=" + "12");
          value = 0;
          eval("blocktype" + number + "=" + value);
          id = "BlockImg" + number;
          document.getElementById(id).src = "Images/Grass.png"
        }
      }
    }
  }
}

function WalkPathLeft(){
  if((frompath == 0) && (topath == 1)){
    number = pos - 1;
    id = "BlockImg" + number;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 4);
    document.getElementById(id).src = source + "PL.png";
    id = "BlockImg" + pos;
    document.getElementById(id).src = "Images/Grass.png";
    pos = number;
  }else if((frompath == 1) && (topath == 0)){
    id = "BlockImg" + number;
    document.getElementById(id).src = "Images/PlayerLeft.png";
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + ".png";
    pos = number;
  }else if((frompath == 1) && (topath == 1)){
    id = "BlockImg" + number;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 4);
    document.getElementById(id).src = source + "PL.png";
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + ".png";
    pos = number;
  }else if(topath == 2){
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + "PL.png";
  }
}

function WalkPathUp(){
  if((frompath == 0) && (topath == 1)){
    number = pos - 10;
    id = "BlockImg" + number;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 4);
    document.getElementById(id).src = source + "PB.png";
    id = "BlockImg" + pos;
    document.getElementById(id).src = "Images/Grass.png";
    pos = number;
  }else if((frompath == 1) && (topath == 0)){
    number = pos - 10;
    id = "BlockImg" + number;
    document.getElementById(id).src = "Images/PlayerBack.png";
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + ".png";
    pos = number;
  }else if((frompath == 1) && (topath == 1)){
    number = pos - 10;
    id = "BlockImg" + number;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 4);
    document.getElementById(id).src = source + "PB.png";
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + ".png";
    pos = number;
  }else if(topath == 2){
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + "PB.png";
  }
}

function WalkPathRight(){
  if((frompath == 0) && (topath == 1)){
    number = pos + 1;
    id = "BlockImg" + number;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 4);
    document.getElementById(id).src = source + "PR.png";
    id = "BlockImg" + pos;
    document.getElementById(id).src = "Images/Grass.png";
    pos = number;
  }else if((frompath == 1) && (topath == 0)){
    number = pos + 1;
    id = "BlockImg" + number;
    document.getElementById(id).src = "Images/PlayerRight.png";
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + ".png";
    pos = number;
  }else if((frompath == 1) && (topath == 1)){
    number = pos + 1;
    id = "BlockImg" + number;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 4);
    document.getElementById(id).src = source + "PR.png";
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + ".png";
    pos = number;
  }else if(topath == 2){
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + "PR.png";
  }
}

function WalkPathDown(){
  if((frompath == 0) && (topath == 1)){
    number = pos + 10;
    id = "BlockImg" + number;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 4);
    document.getElementById(id).src = source + "PF.png";
    id = "BlockImg" + pos;
    document.getElementById(id).src = "Images/Grass.png";
    pos = number;
  }else if((frompath == 1) && (topath == 0)){
    number = pos + 10;
    id = "BlockImg" + number;
    document.getElementById(id).src = "Images/PlayerFront.png";
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + ".png";
    pos = number;
  }else if((frompath == 1) && (topath == 1)){
    number = pos + 10;
    id = "BlockImg" + number;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 4);
    document.getElementById(id).src = source + "PF.png";
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + ".png";
    pos = number;
  }else if(topath == 2){
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + "PF.png";
  }
}

/*
The house blocktypes are 2__ just because reasons!

201 - Quarter Of A House
202 - Half Of A House
203 - Three Quarters Of A House
204 - Whole House Without A Roof
205 - Roofed House
206 - Roofed House With Door
207 - Complete House (With Player Looking Left)
208 - Complete House (With Player Looking Up)
209 - Complete House (With Player Looking Right)
210 - Complete House (With Player Looking Down)
*/

function BuildHouse(){
  if(direction == 1){
    number = pos - 1;
    if(eval("blocktype" + number) == 0){
      value = 201;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/HouseQuarter.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }else if(eval("blocktype" + number) == 201){
      value = 202;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/HouseHalf.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }else if(eval("blocktype" + number) == 202){
      value = 203;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/House3Quarter.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }else if(eval("blocktype" + number) == 203){
      value = 204;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/HouseRoofless.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }
  }else if(direction == 2){
    number = pos - 10;
    if(eval("blocktype" + number) == 0){
      value = 201;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/HouseQuarter.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }else if(eval("blocktype" + number) == 201){
      value = 202;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/HouseHalf.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }else if(eval("blocktype" + number) == 202){
      value = 203;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/House3Quarter.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }else if(eval("blocktype" + number) == 203){
      value = 204;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/HouseRoofless.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }
  }else if(direction == 3){
    number = pos + 1;
    if(eval("blocktype" + number) == 0){
      value = 201;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/HouseQuarter.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }else if(eval("blocktype" + number) == 201){
      value = 202;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/HouseHalf.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }else if(eval("blocktype" + number) == 202){
      value = 203;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/House3Quarter.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }else if(eval("blocktype" + number) == 203){
      value = 204;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/HouseRoofless.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }
  }else if(direction == 4){
    number = pos + 10;
    if(eval("blocktype" + number) == 0){
      value = 201;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/HouseQuarter.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }else if(eval("blocktype" + number) == 201){
      value = 202;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/HouseHalf.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }else if(eval("blocktype" + number) == 202){
      value = 203;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/House3Quarter.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }else if(eval("blocktype" + number) == 203){
      value = 204;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/HouseRoofless.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      wall -= 1;
      document.getElementById('Item1').src = "";
    }
  }
}

function AddRoof(){
  if(direction == 1){
    number = pos - 1;
    if(eval("blocktype" + number) == 204){
      value = 205;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/House.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      roof -= 1;
      document.getElementById('Item1').src = "";
    }
  }else if(direction == 2){
    number = pos - 10;
    if(eval("blocktype" + number) == 204){
      value = 205;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/House.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      roof -= 1;
      document.getElementById('Item1').src = "";
    }
  }else if(direction == 3){
    number = pos + 1;
    if(eval("blocktype" + number) == 204){
      value = 205;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/House.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      roof -= 1;
      document.getElementById('Item1').src = "";
    }
  }else if(direction == 4){
    number = pos + 10;
    if(eval("blocktype" + number) == 204){
      value = 205;
      eval("blocktype" + number + "=" + value);
      id = "BlockImg" + number;
      document.getElementById(id).src = "Images/House.png";
      itemslot1 = 0;
      document.getElementById("ItemName1").innerHTML = "";
      roof -= 1;
      document.getElementById('Item1').src = "";
    }
  }
}

function AddDoor(){
  number = pos - 10;
  value = 206;
  eval("blocktype" + number + "=" + value);
  id = "BlockImg" + number;
  document.getElementById(id).src = "Images/HouseWithDoor.png";
}

function WalkInHouse(){
  number = pos - 10;
  if(eval("blocktype" + pos) == 0){
    direction = 2;
    id = "BlockImg" + number;
    document.getElementById(id).src = "Images/HouseWithPFront.png";
    value = 208;
    eval("blocktype" + number + "=" + value);
    id = "BlockImg" + pos;
    document.getElementById(id).src = "Images/Grass.png";
    pos = number;
  }else if(eval("blocktype" + pos) == 8){
    direction = 2;
    number = pos - 10;
    id = "BlockImg" + number;
    document.getElementById(id).src = "Images/HouseWithPFront.png";
    value = 208;
    eval("blocktype" + number + "=" + value);
    id = "BlockImg" + pos;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 6);
    document.getElementById(id).src = source + ".png";
    pos = number;
  }
}

function WalkOutHouse(){
  number = pos + 10;
  if(eval("blocktype" + number) == 0){
    direction = 4;
    id = "BlockImg" + pos;
    document.getElementById(id).src = "Images/HouseWithDoor.png";
    value = 206;
    eval("blocktype" + pos + "=" + value);
    id = "BlockImg" + number;
    document.getElementById(id).src = "Images/PlayerFront.png";
    pos = number;
  }else if(eval("blocktype" + number) == 8){
    direction = 4;
    id = "BlockImg" + pos;
    document.getElementById(id).src = "Images/HouseWithDoor.png";
    value = 206;
    eval("blocktype" + pos + "=" + value);
    id = "BlockImg" + number;
    source = document.getElementById(id).src;
    source = source.substring(0, source.length - 4);
    document.getElementById(id).src = source + "PF.png";
    pos = number;
  }
}